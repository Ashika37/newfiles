package com.hibernate.mapping;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class App {

	public static void main(String[] args) throws ParseException {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("per");
		EntityManager em= emf.createEntityManager();
		DateFormat date = new SimpleDateFormat("MM-dd-yyyy");
		System.out.println("Starting Transaction");
		em.getTransaction().begin();
		
		
		Author author=new Author();
		author.setName("Walter");
		author.setEmail("js@gmail.com");
		em.persist(author);

		System.out.println("Saving Employee to database");
		
		
		Book book = new Book();
		book.setTitle("Steve Jobs");
		book.setDescription("Biography");
		book.setAuthor(author);
		book.setPublishedDate(date.parse("10-10-2019"));
		em.persist(book);
		em.getTransaction().commit();
		
//		System.out.println("Generated Author  ID ="+author.getId());
//		System.out.println("Generated Book  ID ="+book.getId());


	}

}
