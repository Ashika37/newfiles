package com.hibernate.mapping;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="book")
public class Book {
	@Id
	@Column(name="Book_id")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "seqname")
	@SequenceGenerator(name="seqname", sequenceName="or_seq")
		private long id;
	@Column(name="Book_title")
		private String title;
	@Column(name="Book_desc")
		private String description;
	@Temporal(TemporalType.DATE)
	@Column(name="Published")
		private Date publishedDate;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="Author_id")
		private Author author;

		public Book() {
			
		}
		
		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

	
		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}
		
	

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		
	
		public Date getPublishedDate() {
			return publishedDate;
		}

		public void setPublishedDate(Date publishedDate) {
			this.publishedDate = publishedDate;
		}

	
		public Author getAuthor() {
			return author;
		}

		public void setAuthor(Author author) {
			this.author = author;
		}
		
	
		
		 
		
	
	
}
