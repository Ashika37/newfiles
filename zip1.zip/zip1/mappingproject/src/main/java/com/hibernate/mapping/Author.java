package com.hibernate.mapping;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Author")
public class Author {
	@Id
	@Column(name="Author_id")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "seqname")
	@SequenceGenerator(name="seqname", sequenceName="or_seq")
	private long id;
	@Column(name="Author_name")
	private String name;
	@Column(name="Author_email")

	private String email;
	
	public Author() {
	
	}

	public Author(String name, String email) {
		this.name = name;
		this.email = email;
	}


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Author [id=" + id + ", name=" + name + ", email=" + email + "]";
	}

}
