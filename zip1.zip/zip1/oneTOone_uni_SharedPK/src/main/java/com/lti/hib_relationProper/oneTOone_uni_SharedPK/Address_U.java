package com.lti.hib_relationProper.oneTOone_uni_SharedPK;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
 
@Entity
@Table(name = "ADDRESS_U")
public class Address_U {
	@Id
    @Column(name = "ADDRESS_ID")
    private long id;
 
    @Column(name = "STREET")
    private String street;
 
    @Column(name = "CITY")
    private String city;
 
    @Column(name = "COUNTRY")
    private String country;
 
    public Address_U() {
 
    }
 
    public Address_U(String street, String city, String country) {
        this.street = street;
        this.city = city;
        this.country = country;
    }
 
    
    //getter and setter for id
    public long getId() {
        return id;
    }
 
    public void setId(long id) {
        this.id = id;
    }
 
    //getter and setter fot street
    
    public String getStreet() {
        return street;
    }
 
    public void setStreet(String street) {
        this.street = street;
    }
 
    
    
    //getter and setter fot city
    public String getCity() {
        return city;
    }
 
    public void setCity(String city) {
        this.city = city;
    }
 
    
    
    //getter and setter for country
    public String getCountry() {
        return country;
    }
 
    public void setCountry(String country) {
        this.country = country;
    }

	@Override
	public String toString() {
		return "Address_U [id=" + id + ", street=" + street + ", city=" + city + ", country=" + country + "]";
	}
 
 
}
