package com.lti.hib_relationProper.oneTOone_uni_SharedPK;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
 
@Entity
@Table(name = "STUDENT_U")
public class Student_U {
	 
	    @Id
	    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "gen_SUn")
		@SequenceGenerator(name="gen_SUn", sequenceName="GEN_SUn",allocationSize=1)
	    @Column(name = "STUDENT_ID")
	    private long id;
	 
	    @Column(name = "FIRST_NAME")
	    private String firstName;
	 
	    @Column(name = "LAST_NAME")
	    private String lastName;
	 
	    @Column(name = "SECTION")
	    private String section;
	 
	    @OneToOne(cascade = CascadeType.ALL)
	    @PrimaryKeyJoinColumn
	    private Address_U address;
	 
	    public Student_U() {
	 
	    }
	 
	    public Student_U(String firstName, String lastName, String section) {
	        this.firstName = firstName;
	        this.lastName = lastName;
	        this.section = section;
	    }
	 
	    public long getId() {
	        return id;
	    }
	 
	    public void setId(long id) {
	        this.id = id;
	    }
	 
	    public String getFirstName() {
	        return firstName;
	    }
	 
	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }
	 
	    public String getLastName() {
	        return lastName;
	    }
	 
	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }
	 
	    public String getSection() {
	        return section;
	    }
	 
	    public void setSection(String section) {
	        this.section = section;
	    }

		public Address_U getAddress() {
			return address;
		}

		public void setAddress(Address_U address) {
			this.address = address;
		}

		@Override
		public String toString() {
			return "Student_U [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", section="
					+ section + ", address=" + address + "]";
		}
	 
		
		
	   
	
}
