package com.lti.hib_relationProper.oneTOone_uni_SharedPK;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
     	EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
        EntityManager em=emf.createEntityManager();
        System.out.println("Starting Transaction");
        em.getTransaction().begin();
        
       Student_U s = new Student_U();
       Address_U a = new Address_U();
       
       
       String firstName = "Sush";
       s.setFirstName(firstName);
       String lastName = "hs";
       s.setLastName(lastName);
       String section = "is";
       s.setSection(section);       
       
       String street = "perla";
       a.setStreet(street);
       String city = "mangalore";
       a.setCity(city);
       String country = "India";
       a.setCountry(country);
       
       
       a.setId(s.getId());
   
       s.setAddress(a);
       em.persist(s);
       
     
  
       
       em.getTransaction().commit();
       em.close();
    
    }
}
