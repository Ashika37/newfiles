package com.lti.JPEx.Jpa_Example;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class App 
{
	public static void main( String[] args )
	{
		EntityManagerFactory entityManagerFactory =  Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting Transaction");
		entityManager.getTransaction().begin();
		Employee employee = new Employee();
		
		employee.setName("Ramesh");
		employee.setBranch("Mysuru");
		System.out.println("Saving Employee to Database");

		entityManager.persist(employee);
		entityManager.getTransaction().commit();
		System.out.println("Generated Employee ID ="  + employee.getEmployeeId());
		Employee emp=entityManager.find(Employee.class, employee.getEmployeeId());
		System.out.println("got object " + emp.getName() + " "+emp.getEmployeeId());


		//@SuppressWarnings("unchecked")
//		List<Employee> listEmployee = entityManager.createQuery(" Select e FROM Employee e").getResultList();
//		if(listEmployee == null)
//		{
//			System.out.println("No employee found ");
//		}
//		else
//		{
//			for(Employee emp1: listEmployee){
//				System.out.println("Employee name=" + emp1.getName() + ", Employee id " + emp1.getEmployeeId());
//			}
//		}
		
		
		
		
		
		 Query query=entityManager.createQuery("from Employee");//classname

	     List<Employee> list =query.getResultList();
	     Iterator<Employee> itr =list.iterator();
	     while(itr.hasNext())
	    		 {
	    	 Employee q=itr.next();
	    	 System.out.println("Employee name"+q.getName()+" Emp branch "+q.getBranch());
	    		 }
	    }
//		entityManager.close();
//		entityManagerFactory.close();
	}

