package com.hibernate.onetomanybidir;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="bankaccc")
public class BankAccount {
	
	
	@Id
	@Column(name="Account_no")
	private long acno;
	
	@Column(name="Account_bal")
	private long bal;
	
	@ManyToOne(optional=false)
	
	@JoinColumn(name="customer_id")
	private Customer customer;



	public BankAccount(long acno, long bal) {
	
		this.acno = acno;
		this.bal = bal;
		
	}

	public BankAccount() {
		
	}

	public long getAcno() {
		return acno;
	}

	public void setAcno(long acno) {
		this.acno = acno;
	}

	public long getBal() {
		return bal;
	}

	public void setBal(long bal) {
		this.bal = bal;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "BankAccount [acno=" + acno + ", bal=" + bal + ", customer=" + customer + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (acno ^ (acno >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankAccount other = (BankAccount) obj;
		if (acno != other.acno)
			return false;
		return true;
	}
	
	
	

}
