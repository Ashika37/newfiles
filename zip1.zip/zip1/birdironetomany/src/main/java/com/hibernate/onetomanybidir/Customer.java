package com.hibernate.onetomanybidir;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="customers")
public class Customer {
	
	@Id
	@Column(name="customer_id")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "seqname")
	@SequenceGenerator(name="seqname", sequenceName="or_seq")
	private int id;
	@Column(name="customer_name")
	private String name;
	
	@Column(name="customer_address")
	private String address;
	 @Column(name="customer_phno")
	private long phno;
	 
	 @OneToMany(mappedBy="customer", cascade = CascadeType.ALL )
	private List<BankAccount> bankAcc;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getPhno() {
		return phno;
	}
	public void setPhno(long phno) {
		this.phno = phno;
	}
	 
	public List<BankAccount> getBankAcc() {
		return bankAcc;
	}
	public void setBankAcc(List<BankAccount> bankAcc) {
		this.bankAcc = bankAcc;
	}
	public Customer(String name, String address, long phno) {
		super();
		this.name = name;
		this.address = address;
		this.phno = phno;
	}
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", address=" + address + ", phno=" + phno + "]";
	}
	
	
	
	 

	
	
	
}
