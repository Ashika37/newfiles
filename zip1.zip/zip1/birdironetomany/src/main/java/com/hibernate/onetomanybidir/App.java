package com.hibernate.onetomanybidir;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("per");
		EntityManager em= emf.createEntityManager();
		
	BankAccount b1 = new BankAccount(123456,5454);
	BankAccount b2 = new BankAccount(86246856,58764);
	BankAccount b3 = new BankAccount(4654654,87456);
	Customer c = new Customer("jas","10 Marks St.",9874563210L);
	List<BankAccount> bl = new ArrayList<BankAccount>();
	b1.setCustomer(c);
	b2.setCustomer(c);
	b3.setCustomer(c);

	bl.add(b1);
	bl.add(b2);
	bl.add(b3);	
	c.setBankAcc(bl);


	em.getTransaction().begin();
	em.persist(c);
	em.getTransaction().commit();
	em.close();
	
	
	}
}
