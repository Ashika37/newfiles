package com.lti.hib_ex.Hibernate_JPA;

public class methods {

}
