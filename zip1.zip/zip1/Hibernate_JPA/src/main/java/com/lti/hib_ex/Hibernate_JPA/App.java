package com.lti.hib_ex.Hibernate_JPA;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("Persistence");
        EntityManager entityManager =entityManagerFactory.createEntityManager();
        
        
        System.out.println("Starting transaction");
        entityManager.getTransaction().begin();
        Employee12 employee=new Employee12();
        employee.setName("Ronaldo");
        employee.setBranch("Juventus");
        System.out.println("Saving employee to database");
        
        entityManager.persist(employee);
        entityManager.getTransaction().commit();
        System.out.println("Generated Employee ID = " +employee.getEmployeeId());
        Employee12 emp=entityManager.find(Employee12.class, employee.getEmployeeId());
        
        @SuppressWarnings("unchecked")
        List<Employee12> listEmployee=entityManager.createQuery("Select e from Employee12 e").getResultList();
        
        if(listEmployee == null)
        {
        	System.out.println("No employee found.");
        }
        else
        {
        	for(Employee12 emp1 : listEmployee)
        	{
        		System.out.println("Employee name= " + emp1.getName() + ", Employee id " + emp1.getEmployeeId());
        	}
        }
        entityManager.close();
        entityManagerFactory.close();
    }
}
