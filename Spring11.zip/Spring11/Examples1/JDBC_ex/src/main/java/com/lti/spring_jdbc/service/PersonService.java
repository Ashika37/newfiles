package com.lti.spring_jdbc.service;

import java.util.List;

import com.lti.spring_jdbc.JDBC_ex.Person;



public interface PersonService {
	public void addPerson(Person person);
	public void editPerson(Person person, int personId);
	public void deletePerson(int personId);
	public Person find(int personId);
	public List < Person > findALL();
}
