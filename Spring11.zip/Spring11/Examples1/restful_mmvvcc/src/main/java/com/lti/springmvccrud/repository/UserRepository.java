package com.lti.springmvccrud.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.lti.springmvccrud.entity.User;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {
	
	

}
