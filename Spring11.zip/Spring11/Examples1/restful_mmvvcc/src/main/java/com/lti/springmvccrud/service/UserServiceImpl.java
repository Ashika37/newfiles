package com.lti.springmvccrud.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.lti.springmvccrud.entity.User;
import com.lti.springmvccrud.repository.UserRepository;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	
	private UserRepository repository;
	
	public  UserServiceImpl() {
		
	}
	
	public UserServiceImpl(UserRepository repository) {
		super();
		this.repository = repository;
		
	}

	public List<User> getAllUsers() {
		List<User> list = new ArrayList<User>();
		repository.findAll().forEach(e -> list.add(e));
		return list;
	}
	
	public User getUserbyId(Long id) {
		User user = repository.findById(id).get();
		return user;
	}
	
	public boolean saveUser(User user) {
		try {
			repository.save(user);
			return true;
			}catch(Exception ex) {
				return false;
			}
		}
	public boolean deleteById(Long id){
		try{
			repository.deleteById(id);
			return true;
		}catch(Exception ex){
			return false;
		}
	}

	@Override
	public User getUserById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteUserById(long id) {
		// TODO Auto-generated method stub
		return false;
	}
}
