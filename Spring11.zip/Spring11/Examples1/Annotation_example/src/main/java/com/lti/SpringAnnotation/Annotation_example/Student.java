package com.lti.SpringAnnotation.Annotation_example;

public class Student {

	int student_id;
	String student_Name;
	
	public Student(int student_id, String student_Name) {
		super();
		this.student_id = student_id;
		this.student_Name = student_Name;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public String getStudent_Name() {
		return student_Name;
	}

	public void setStudent_Name(String student_Name) {
		this.student_Name = student_Name;
	}
	
	
private Country country;

public Country getCountry() {
	return country;
}

public void setCountry(Country country) {
	this.country = country;
}

public Student(int student_id, String student_Name, Country country) {
	super();
	this.student_id = student_id;
	this.student_Name = student_Name;
	this.country = country;
}

@Override
public String toString() {
	return "Student [student_id=" + student_id + ", student_Name=" + student_Name + ", country=" + country + "]";
}

	
	
}
