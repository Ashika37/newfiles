package com.lti.SpringAnnotation.Annotation_example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    
    	ApplicationContext appContext = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
    	
    	Country countryObj = (Country) appContext.getBean("countryObj");
    	String countryName=countryObj.getCountryName();
    	
    	Student studentObj = (Student) appContext.getBean("studentObj");
    	int student_id = studentObj.getStudent_id();
    	String student_Name=studentObj.getStudent_Name();
    	Country student_country =studentObj.getCountry();
    	
    	System.out.println("Country name:" + countryName +"\n");
    	
    	System.out.println("Student name:" + student_id);
    	System.out.println("Student name:" + student_Name+"\n");
    	
    	System.out.println("Student name:" + student_id);
    	System.out.println("Student name:" + student_Name);
    	System.out.println("Student country:" +student_country );
    }
}
