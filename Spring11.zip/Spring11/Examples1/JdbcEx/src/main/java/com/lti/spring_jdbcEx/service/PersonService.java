package com.lti.spring_jdbcEx.service;

import java.util.List;

import com.lti.Spring_jdbc.JdbcEx.Person;

public interface PersonService {

	public void addPerson(Person person);
	public void editPerson(Person person, int personId);
	public void deletePerson(int personId);
	public Person find(int personId);
	public List < Person > findALL();
}
