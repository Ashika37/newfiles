package com.lti.spring_jdbcEx.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.Spring_jdbc.JdbcEx.Person;
import com.lti.spring_jdbcEx.dao.PersonDao;

@Service("personService")
public class PersonServiceImpl {

	@Autowired
	PersonDao personDao;
	
	public void addPerson(Person person){
		personDao.addPerson(person);
	}
	
	public void editPerson(Person person , int personId){
		personDao.editPerson(person, personId);
	}
	
	public void deletePerson(int personId){
		personDao.deletePerson(personId);
	}
	
	public Person find(int personId){
		return personDao.find(personId);
	}
	
	public List < Person > findALL(){
		return personDao.findALL();
	}
	
}
