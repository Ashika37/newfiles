package com.lti.SpringDependencyAnnotation.component_dep_ann;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages="com.lti.SpringDependencyAnnotation.component_dep_ann")  //it scans the whole pkg
public class AppConfig {
	
	@Bean
	public Employee getEmployee(){
		return new EmployeeImpl();
	}
	
	@Bean 
	public Department getDepartment(){
		return new DeptImpl();
	}

}
