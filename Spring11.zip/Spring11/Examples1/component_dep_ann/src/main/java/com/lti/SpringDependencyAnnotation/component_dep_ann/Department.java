package com.lti.SpringDependencyAnnotation.component_dep_ann;

public interface Department {
	void showDepartmentInfo();
	
}
