package com.lti.SpringDependencyAnnotation.component_dep_ann;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
    	
    	Company company = context.getBean(Company.class);
    	company.showDepartmentInfo();
    	company.showEmployeeInfo();
    	context.close();
    }
}
