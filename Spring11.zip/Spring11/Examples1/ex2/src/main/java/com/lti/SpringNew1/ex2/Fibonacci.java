package com.lti.SpringNew1.ex2;

public interface Fibonacci {

	public void fibonacci(int count1);
}
