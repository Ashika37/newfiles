package com.lti.SpringCollection.Collection_Example;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

public class CollectionBean {

	@Autowired
	private List<String> nameList;
	
	
	public void printNameList(){
		System.out.println(nameList);
	}
	
	@Autowired
	private Set<String> nm;
	@Autowired
	public void printNameList1(){
		System.out.println(nm);
	}
	


}
