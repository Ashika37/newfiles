package com.lti.SpringCollection.Collection_Example;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CollectionConfig {
	
	@Bean
	public CollectionBean getCollectionBean(){
		return new CollectionBean();
	}
	
	@Bean
	public List<String> nameList(){
		return Arrays.asList("John","Adam","Harry");
	}
	
	@Bean
	public Set<Integer> nm()
	{
		Set<Integer> i= new HashSet<Integer>();
		i.add(10);
		i.add(20);
		return i;
	}
	
}
