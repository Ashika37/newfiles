package com.lti.SpringNew.Spring_ex;

public class HelloworldImpl implements HelloWorld{

	public void printMessage(String message){
		System.out.println(message);
	}
}
