package com.lti.spring_jpa.service;

import java.util.List;

import com.lti.spring_jpa.JPA_EX.Person;

public interface PersonService {

	void add(Person person);
	List<Person> listPersons();
}
