package com.lti.spring_jpa.dao;

import java.util.List;

import com.lti.spring_jpa.JPA_EX.Person;

public interface PersonDao {
	
	void add(Person person);
	List < Person > listPersons();

}
