package com.lti.SpringsetterInjection.SetterInj;

import java.applet.AppletContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext ctx = new
    		   ClassPathXmlApplicationContext("beans.xml");
      Trainee obj = (Trainee) ctx.getBean("tr");
      
   
      
      System.out.println("Enter the Name");
      String str1 = obj.getTname();
      
      System.out.println("Age");
      int str = obj.getId();
      
      System.out.println("Enter the Country");
      String str11 = obj.getCountry();
      
      Trainee(str1,str,str11);
       System.out.println(obj);
    }

	private static void Trainee(String str1, int str, String str11) {
		// TODO Auto-generated method stub
		
	}
}
