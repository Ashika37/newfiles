package com.lti.CollegeDatabase.Pro;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Student30")
public class Student {
	
	private long stu_id;
	private String stu_name;
	private long stu_dob;
	public Student( String stu_name, long stu_dob) {
		super();
		
		this.stu_name = stu_name;
		this.stu_dob = stu_dob;
	}
	public Student(){}
	
	
	@Id
	@Column(name="stu_id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="somesequenceNames")
	@SequenceGenerator(name="somesequenceNames",sequenceName="stu_seq20",allocationSize =1)
	public long getStu_id() {
		return stu_id;
	}
	public void setStu_id(long stu_id) {
		this.stu_id = stu_id;
	}
	@Column(name="stu_name")
	public String getStu_name() {
		return stu_name;
	}
	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}
	@Column(name="stu_dob")
	public long getStu_dob() {
		return stu_dob;
	}
	public void setStu_dob(long stu_dob) {
		this.stu_dob = stu_dob;
	}
	@Override
	public String toString() {
		return "Student [stu_id=" + stu_id + ", stu_name=" + stu_name + ", stu_dob=" + stu_dob + "]";
	}
	

}
