package com.lti.CollegeDatabase.Pro;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Course30")
public class Course {
	
	private long course_id;
	private String course_name;
	private long duration;
	public Course() {
		super();
	}
	public Course(String course_name, long duration) {
		super();
		
		this.course_name = course_name;
		this.duration = duration;
		
	}
	
	@Id
	@Column(name="Course_id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="somesequenceNamec")
	@SequenceGenerator(name="somesequenceNamec",sequenceName="course_seq20",allocationSize =1)
	public long getCourse_id() {
		return course_id;
	}
	public void setCourse_id(long course_id) {
		this.course_id = course_id;
	}
	@Column(name="course_name")
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	@Column(name="Duration")
	public long getDuration() {
		return duration;
	}
	public void setDuration(long duration) {
		this.duration = duration;
	}
	
	private Set<Student> student;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="Course_id")
	public Set<Student> getStudent() {
		return student;
	}

	public void setStudent(Set<Student> student) {
		this.student = student;
	}
	@Override
	public String toString() {
		return "Course [course_id=" + course_id + ", course_name=" + course_name + ", duration=" + duration
				+ ", student=" + student + "]";
	}
	

}
