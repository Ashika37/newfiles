package com.lti.CollegeDatabase.Pro;

import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App 
{
    
  
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("persistence");
    EntityManager entityManager=entityManagerFactory.createEntityManager();
	Scanner sc=new Scanner(System.in);
	public void insert(){

    System.out.println("Starting Transaction");
    entityManager.getTransaction().begin();
    
    Department department = new Department();
	System.out.println("Enter Department name :");
	String dn=sc.next();
	department.setDept_name(dn);
	System.out.println("Enter Department location:");
	String dl=sc.next();
	department.setLocation(dl);

    System.out.println("Data Added to department");
    


	Instructor instructor = new Instructor();
	System.out.println("Enter instructor name :");
	String in=sc.next();
	instructor.setInst_name(in);
	
	System.out.println("Enter instructor phone :");
	long ip =sc.nextLong();
	instructor.setPhone_no(ip);
	
	System.out.println("Enter instructor room :");
	long ir =sc.nextLong();
	instructor.setRoom_no(ir);
	 Set<Instructor> emp=new HashSet<Instructor>();
	 emp.add(instructor);
	 department.setInstructors(emp);
	 System.out.println("Data Added to  instructor");
	 
	 Course course = new Course();
	 System.out.println("Enter course name :");
		String cn=sc.next();
		course.setCourse_name(cn);
		
		System.out.println("Enter course duration :");
		long cd =sc.nextLong();
		course.setDuration(cd);
		Set<Course> cou =new HashSet<Course>();
		 cou.add(course);
		 
		instructor.setCourse(cou);
		System.out.println("Data Added to course");

		
		Student student = new Student();
		 System.out.println("Enter student name :");
			String sn=sc.next();
			student.setStu_name(sn);
			
			System.out.println("Enter student dob :");
			long sd =sc.nextLong();
			student.setStu_dob(sd);
			Set<Student> sou =new HashSet<Student>();
			 sou.add(student);
			 instructor.setStudent(sou);
			 course.setStudent(sou);
			 System.out.println("Data Added to student");
			 
        entityManager.persist(department);
        entityManager.persist(instructor);
        entityManager.persist(course);

        entityManager.getTransaction().commit();
        
      

}
	public void displayDepartment(){
		System.out.println("Department details");
		@SuppressWarnings("unchecked")
		 
		 List<Department> listOrders = entityManager.createQuery("SELECT e FROM Department e").getResultList();
		  if(listOrders == null){
			   System.out.println("No orders found");
		  }else{
			  for(Department ord12 : listOrders){
				  System.out.println("Department name =" + ord12.getDept_name() + ",Department id ="+ ord12.getDept_id() + ",Department location ="+ ord12.getLocation() );
			  }
		  }
	}
	
	public void displayInstructor(){
		System.out.println("Instructor details");

		@SuppressWarnings("unchecked")
		 
		 List<Instructor> listins= entityManager.createQuery("SELECT e FROM Instructor e").getResultList();
		  if(listins == null){
			   System.out.println("No orders found");
		  }else{
			  for(Instructor ins14 : listins){
				  System.out.println(" Instructor name =" + ins14.getInst_name() + ",Instructor id ="+ ins14.getInst_id() + ",Instructor phone ="+ ins14.getPhone_no()+ ",Instructor room ="+ ins14.getRoom_no() );
			  }
		  }
	}
	public void updateDepart(){
		 System.out.println("Enter Id for Updating Department");
			
		 long id_find=sc.nextLong();
		 Department ord1 = (Department)entityManager.find(Department.class, id_find);
		 System.out.println("get object" +" "+ ord1.getDept_id() + " " + ord1.getDept_name()+ " " +ord1.getLocation());
		
		 System.out.println("Enter New Department Name for Updating");
		 String U_name=sc.next();
		 ord1.setDept_name(U_name);
		
		 System.out.println("Enter New Location for Updating");
		 String U_loc=sc.next();
		 ord1.setLocation(U_loc);
		 entityManager.getTransaction().begin();
		 entityManager.merge(ord1);
		 
		 entityManager.getTransaction().commit();
		 System.out.println("successfully updated to db");
	}
	
	public void updateInstructor(){
		 System.out.println("Enter Id for Updating Instructor");
			
		 long id_ins=sc.nextLong();
		 Instructor ord2 = (Instructor)entityManager.find(Instructor.class, id_ins);
		 System.out.println("get object" +" "+ ord2.getInst_id() + " " + ord2.getInst_name()+ " " +ord2.getPhone_no()+ " " +ord2.getRoom_no());
		
		 System.out.println("Enter New Instructor Name for Updating");
		 String I_name=sc.next();
		 ord2.setInst_name(I_name);
		
		 System.out.println("Enter New Room number for Updating");
		 int I_room=sc.nextInt();
		 ord2.setRoom_no(I_room);
		 entityManager.getTransaction().begin();
		 entityManager.merge(ord2);
		 
		 entityManager.getTransaction().commit();
		 System.out.println("successfully updated to db");
	}
	
	public void deleteDepart(){
		 System.out.println("Enter Department id for deleting");
		 long deptid = sc.nextLong();
		 Department or = entityManager.find(Department.class, deptid);
		 entityManager.getTransaction().begin();
		 entityManager.remove(or);
		entityManager.getTransaction().commit();
		System.out.println("successfully removed to db");
	}
	
	public void deleteInstructor(){
		 System.out.println("Enter Instructor id for deleting");
		 long instid = sc.nextLong();
		 Instructor or1 = entityManager.find(Instructor.class, instid);
		 entityManager.getTransaction().begin();
		 entityManager.remove(or1);
		entityManager.getTransaction().commit();
		System.out.println("successfully removed to db");
		entityManager.close();
	}
public static void main(String args[]){
App a = new App();
do{
Scanner sc=new Scanner(System.in);
int ch;
System.out.println("1. Insert to department and instructor");
System.out.println("2. Display department details");
System.out.println("3. Display instructor details");
System.out.println("4. update department details");
System.out.println("5. update instructor details");
System.out.println("6. Delete department details");
System.out.println("7. Delete instructor details");
System.out.println("enter the choice");
ch = sc.nextInt();
switch(ch){
case 1: a.insert();break;
case 2: a.displayDepartment();break;
case 3: a.displayInstructor();break;
case 4: a.updateDepart();break;
case 5: a.updateInstructor();break;
case 6: a.deleteDepart();break;
case 7: a.deleteInstructor();break;
}
}while(true);

}
  
    }
