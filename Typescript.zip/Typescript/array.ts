var cities : string[]=["Berlin", "Quebec", " New York"]
var primes: number[]=[1,3,5,7,11,13]
var bools:boolean[] =[true,false,false,true]

var list: Array<number>=[1,2,3]

console.log(cities);
console.log(primes); 
console.log(bools);