class person{
	name:string;
	age:number;

	constructor(name:string , age:number){
		this.name=name;
		this.age=age;
	}
	getName(): string{
		return this.name;
	}
	getAge(): number{
		return this.age
	}
}

class Student extends person{
	tmarks:number;
	getMarks():number{
		return this.tmarks;
	}
	setMarks(tmarks){
		this.tmarks=tmarks;
	}
}

let _std1 = new Student('Sheena',24);
console.log(_std1.getAge());
_std1.setMarks(500);
console.log(_std1.getMarks());

