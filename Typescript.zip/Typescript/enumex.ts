enum Color{Red, Green, Blue};
var c : Color = Color.Green;
enum Color1 {Red=0 , Green ,Blue};
enum Color2 {Red=3 ,Green ,Blue};


console.log(Color);
console.log(Color1);
console.log(Color2);
