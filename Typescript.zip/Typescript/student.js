var Student = /** @class */ (function () {
    function Student(age, name, roll_no) {
        this.age = age;
        this.name = name;
        this.roll_no = roll_no;
    }
    Student.prototype.getRollNo = function () {
        return this.roll_no;
    };
    Student.prototype.getName = function () {
        return this.name;
    };
    Student.prototype.getAge = function () {
        return this.age;
    };
    return Student;
}());
var student_details = new Student(15, "Harry John", 33);
console.log(student_details.getAge());
console.log(student_details.getName());
console.log(student_details.getRollNo());
