var isDone = false;
var Lines = 42;
var name = "Hello World";
function bigHorribleAlert() {
    alert(" I'm a little annoying box!");
}
