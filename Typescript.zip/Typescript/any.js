var notSure = 4;
notSure = "may be a string instead";
notSure = false;
console.log(notSure);
