var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var person = /** @class */ (function () {
    function person(name, age) {
        this.name = name;
        this.age = age;
    }
    person.prototype.getName = function () {
        return this.name;
    };
    person.prototype.getAge = function () {
        return this.age;
    };
    return person;
}());
var Student = /** @class */ (function (_super) {
    __extends(Student, _super);
    function Student() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Student.prototype.getMarks = function () {
        return this.tmarks;
    };
    Student.prototype.setMarks = function (tmarks) {
        this.tmarks = tmarks;
    };
    return Student;
}(person));
var _std1 = new Student('Sheena', 24);
console.log(_std1.getAge());
_std1.setMarks(500);
console.log(_std1.getMarks());
