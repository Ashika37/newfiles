var isDone: boolean = false;
var Lines: number = 42;
var name: string = "Hello World";

function bigHorribleAlert(): void {
 alert(" I'm a little annoying box!");
}