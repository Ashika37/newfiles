package com.lti.springMvc.service;

import java.util.List;

import com.lti.springMvc.entity.Author;

public interface AuthorService {
	public  List<Author> getAllUsers();
	public Author getUserById(Long id);
	public  boolean saveUser(Author user);
	public  boolean deleteUserById(Long id);
}
