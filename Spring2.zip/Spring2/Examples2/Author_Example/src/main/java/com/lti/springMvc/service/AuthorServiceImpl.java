package com.lti.springMvc.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.springMvc.entity.Author;
import com.lti.springMvc.repository.AuthorRepository;

@Service
@Transactional
public class AuthorServiceImpl implements AuthorService{
	// Implementing Constructor based DI
			private AuthorRepository repository;
			
			public AuthorServiceImpl() {
				
			}
			
			@Autowired
			public AuthorServiceImpl(AuthorRepository repository) {
				super();
				this.repository = repository;
			}
			
		public List<Author> getAllUsers() {
			 List<Author> list = new ArrayList<Author>();
			repository.findAll().forEach(e -> list.add(e));
			return list;
		}

		public Author getUserById(Long id) {
			Author user = repository.findById(id).get();
			return user;
		}

		public boolean saveUser(Author user) {
			try {
				repository.save(user);
				return true;
			}catch(Exception ex) {
				return false;
			}
		}

		public boolean deleteUserById(Long id) {
			try {
				repository.deleteById(id);
				return true;
			}catch(Exception ex) {
				return false;
			}
			
		}
}
