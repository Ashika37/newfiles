package com.lti.springMvc.repository;

import org.springframework.data.repository.CrudRepository;

import com.lti.springMvc.entity.Author;

public interface AuthorRepository extends 
CrudRepository<Author, Long> {

}
