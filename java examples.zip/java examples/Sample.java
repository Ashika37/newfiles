public class Sample
{
public static void main(String args[]){
System.out.println("Welcome To Java World ......");
}
}


class Sample1
{
public static void main(String args[]){
System.out.println("Welcome To Java World ......");
}
}


class Sample2
{
public static void main(String args[]){
System.out.println("Welcome To Java World ......");
}
}