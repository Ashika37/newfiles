public class arraycopydemo{
	public static void main(String[] args){
		char[] fromarr = { 'H','E','L','L','O','W','O','R','L','D'};
		char[] toarr = new char[4];

	System.arraycopy(fromarr,0,toarr,0,4);
	for(int x=0; x<toarr.length;x++)	
	{
	System.out.println(toarr[x]);
	}
}
}