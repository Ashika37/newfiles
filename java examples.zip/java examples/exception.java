class Exception_Ex
{
static void disp()
{
try

int a[]={2,3,4,5};
System.out.println(a[4]);
}
catch(Exception e){
System.out.println(e.getMessage());
}
}

public static void main(String 1[]){
Exception_Ex.disp();
}
}
