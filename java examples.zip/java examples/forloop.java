public class forloop{
public static void main(String args[]){
for( int i =1; i<10 ; i=i+1){
if( i!=5){
int n=i*6;
System.out.println("n="+n);
System.out.println("\n");
}
}
}
}