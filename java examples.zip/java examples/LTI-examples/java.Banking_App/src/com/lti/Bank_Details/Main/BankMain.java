package com.lti.Bank_Details.Main;
import com.lti.Bank_Details.beanclasses.BankAccBean;
import com.lti.Bank_Details.beanclasses.CustomerBean;

public class BankMain {

	public static void main(String[] args) {
		CustomerBean cb= new CustomerBean("Shan","Inamdar","shan@gmail.com","9845868758");
		BankAccBean bb = new BankAccBean("ici101",cb,250000.0);
				System.out.println(bb);

	}

}
