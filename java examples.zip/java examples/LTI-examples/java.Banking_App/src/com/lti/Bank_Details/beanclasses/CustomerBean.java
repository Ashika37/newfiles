package com.lti.Bank_Details.beanclasses;

public class CustomerBean {

	  private String fname;
	  private String lname;
	  private String email;
	  private String phoneno;
	public CustomerBean(String fname, String lname, String email, String phoneno) {
		this.fname = fname;
		this.lname = lname;
		this.email = email;
		this.phoneno = phoneno;
	}

	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	@Override
	public String toString() {
		return "CustomerBean [fname=" + fname + ", lname=" + lname + ", email=" + email + ", phoneno=" + phoneno + "]";
	}
	
	  

}
