package com.lti.Bank_Details.beanclasses;

public class BankAccBean {
	private String accno;
	private CustomerBean owner;
	private double balance;
	
	public BankAccBean(String accno, CustomerBean owner, double balance) {
		this.accno = accno;
		this.owner = owner;
		this.balance = balance;
	}
	public String getAccno() {
		return accno;
	}
	public void setAccno(String accno) {
		this.accno = accno;
	}
	public CustomerBean getOwner() {
		return owner;
	}
	public void setOwner(CustomerBean owner) {
		this.owner = owner;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "BankAccBean [accno=" + accno + ", owner=" + owner + ", balance=" + balance + "]";
	}

}
