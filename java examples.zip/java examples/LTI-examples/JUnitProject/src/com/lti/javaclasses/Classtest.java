package com.lti.javaclasses;

import static org.junit.Assert.*;
import org.junit.*;

import java.util.ArrayList;
import java.util.List;

public class Classtest {
	@Test
	public void test() {
		List<Integer> list = new ArrayList<>();
		list.add(42);
		list.add(-3);
		list.add(15);
		assertEquals(42,list.get(0));
		assertEquals(-3,list.get(1));
		assertEquals(15,list.get(2));
	}
	
	public void testisempty() {
		List<Integer> list = new ArrayList<>();
		assertTrue(list.isEmpty());
		list.add(123);
		assertFalse(list.isEmpty());
		list.remove(0);
		
	}

}
