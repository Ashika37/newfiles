package com.lti.Details;

public class Instructor {
 
	private String Inst_name;
	private int Inst_id;
	private int Duration;
	private int Room;
	
	public Instructor(String inst_name, int inst_id, int duration, int room) {
		Inst_name = inst_name;
		Inst_id = inst_id;
		Duration = duration;
		Room = room;
		
	}

	public String getInst_name() {
		return Inst_name;
	}
	public void setInst_name(String inst_name) {
		Inst_name = inst_name;
	}
	public int getInst_id() {
		return Inst_id;
	}
	public void setInst_id(int inst_id) {
		Inst_id = inst_id;
	}
	public int getDuration() {
		return Duration;
	}
	public void setDuration(int duration) {
		Duration = duration;
	}
	public int getRoom() {
		return Room;
	}
	public void setRoom(int room) {
		Room = room;
	}

	@Override
	public String toString() {
		return "Instructor [Inst_name=" + Inst_name + ", Inst_id=" + Inst_id + ", Duration=" + Duration + ", Room="
				+ Room + "]";
	}



}

