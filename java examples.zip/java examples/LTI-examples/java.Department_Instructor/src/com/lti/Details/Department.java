package com.lti.Details;

public class Department {
 private int Dept_id;
 private String Dept_name;
 private String Dept_loc;
 private Instructor i;
public Department(int dept_id, String dept_name, String dept_loc, Instructor i) {
	Dept_id = dept_id;
	Dept_name = dept_name;
	Dept_loc = dept_loc;
	this.i = i;
}

public int getDept_id() {
	return Dept_id;
}
public void setDept_id(int dept_id) {
	Dept_id = dept_id;
}
public String getDept_name() {
	return Dept_name;
}
public void setDept_name(String dept_name) {
	Dept_name = dept_name;
}
public String getDept_loc() {
	return Dept_loc;
}
public void setDept_loc(String dept_loc) {
	Dept_loc = dept_loc;
}
public Instructor getI() {
	return i;
}
public void setI(Instructor i) {
	this.i = i;
}

@Override
public String toString() {
	return "Department [Dept_id=" + Dept_id + ", Dept_name=" + Dept_name + ", Dept_loc=" + Dept_loc + ", i=" + i + "]";
}
 

 
}
