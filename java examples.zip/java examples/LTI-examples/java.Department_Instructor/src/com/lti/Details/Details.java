package com.lti.Details;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.lti.Details.Department;
import com.lti.Details.Instructor;

public class Details {

	// Instructor i1 = new Instructor("Asha",20,10,222);
	//	Department d1 = new Department(1,"CSE","BANGALORE",i1);		  
	//System.out.println(d1);
		 
		public static void dept_inst_info() {
				List<Department> di = new ArrayList<>();
				List<Instructor> ii = new ArrayList<>();
				
				ii.add(new Instructor("Mohan",11,10,999));
				di.add(new Department(1,"CSE","Bangalore", ));
		}
			

			//	l1.add(new Book(1234455,1101,321,"Raw"));
			//	l1.add(new Book(12348975,1102,321,"Mossad"));
			//	l1.add(new Book(1784455,1103,321,"KGB"));
			// Iterator<book> itr=li.iterator();
			//	while(itr.hasNext()) {
			//		Book b = itr.next();
			//		System.out.println(b);
				//}
					public static void main (String[] args) {
						
			}
		 
	}
