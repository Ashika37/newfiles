package com.lti.threadEx;

class MyThread extends Thread {
	MyThread(String threadName) {
	super(threadName);
	System.out.println(threadName);
}

//public void run() {
	//for(int i=0; i<10; i++) {
	//	System.out.println(i+ " " + getName());
		//try {
	//		sleep((long) (Math.random() * 1000));        //using this will start it again and	
	//	}catch(InterruptedException e) {}                //agin after sleeping for a while
	//}
//}
}
public class ThreadEx12 {
	public static void main(String args[])
	{
		MyThread t= new MyThread ("Amit");
		t.start();
		MyThread t1= new MyThread ("Shaan");
		t1.start();
		MyThread t2= new MyThread ("Raaj");
		t2.start();
		
	}
}
