package com.lti.threadEx;

class MyThread11 implements Runnable {
	public void run() {
		for(int i=0; i<4; i++){
			System.out.println(Thread.currentThread());
			try {
				Thread.sleep((long)(Math.random()+ 100));
			}catch(InterruptedException e) {}
		}
	}
}
public class ThreadEx121 {
	public static void main(String args[]) throws InterruptedException
	{
		MyThread11 t= new MyThread11();
		
		Thread mt1=new Thread();
		mt1.setName("Amit");
        mt1.start();
		mt1.join();
		
		MyThread11 t1= new MyThread11();
		
		Thread mt2=new Thread();
		
		mt2.setName("Shaan");
		mt2.start();
        
		
	}
}



