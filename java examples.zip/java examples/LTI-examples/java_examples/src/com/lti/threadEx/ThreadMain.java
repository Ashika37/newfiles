package com.lti.threadEx;

class Thread1 extends Thread{
	//@override
	public void run() {
		System.out.println("First Thread Example:" + Thread.currentThread());
	}
}

public class ThreadMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Thread1 t=new Thread1() ;
		 t.start() ;

	}

}
