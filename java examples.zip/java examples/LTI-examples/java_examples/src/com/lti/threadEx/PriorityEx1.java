package com.lti.threadEx;
class priorityThreadA extends Thread
{
	public void run()
	System.out.priontln("ThreafA started");
	for(int i=2; i>0; i--) {
		System.out.priontln("From ThreadA: i ="+i);
	}
	System.out.priontln("existing");
}
	
}
class priorityThreadB extends Thread
{
	public void run()
	System.out.priontln("ThreafB started");
	for(int j=2; j>0; j--) {
		System.out.priontln("From ThreadB: j ="+j);
	}
	System.out.priontln("existing");
}
	
}
class priorityThreadC extends Thread
{
	public void run()
	System.out.priontln("ThreafC started");
	for(int k=2; k>0; k--) {
		System.out.priontln("From ThreadC: k ="+k);
	}
	System.out.priontln("existing");
}
	
}

public class PriorityEx1 {
	public static void main(String args[])
	{
		priorityThreadA t1= new priorityThreadA();
		priorityThreadB t2= new priorityThreadB();
		priorityThreadC t3= new priorityThreadC();
		try {
			t1.start();
			t1.setPriority(Thread.NORM_PRIORITY+1);  //6
			t1.jain();
			
			t2.start();
			t2.setPriority(Thread.NORM_PRIORITY-2);  //3
			
			t3.start();
			t3.setPriority(Thread.NORM_PRIORITY+4);  //9
		}
		catch(exception e)()
		
	}

}
