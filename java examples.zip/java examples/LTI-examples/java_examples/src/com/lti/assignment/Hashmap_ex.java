package com.lti.assignment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Hashmap_ex {
	public static void main(String[] args) {
		Map<String, Employee> employeeMap = new HashMap<String, Employee>();
		
		employeeMap.put("M100033", new Employee(200,"Karthik",56777.00));
		
		employeeMap.put("M100022", new Employee(345,"Bharath",96777.00));
		employeeMap.put("M100062", new Employee(500,"Sujay",3999.00));
		
		
		Employee emp = (Employee) employeeMap.get("M100022");
		System.out.println(emp);
		
		Iterator<String> iter =employeeMap.keySet().iterator();
		
		while(iter.hasNext())
		{
			String eid=iter.next();
			System.out.println(eid);
		}
		
		Set<Map.Entry<String, Employee>> entrySet =employeeMap.entrySet();
		for(Map.Entry<String, Employee> entry : entrySet)
		{
			System.out.println(entry.getKey() + "---->" + entry.getValue());
		}
	}
}
