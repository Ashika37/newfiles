package com.lti.jdbcExamples;
import java.sql.*;
import java.sql.CallableStatement;
import java.sql.Connection;


public class callable_statement_example {
	public static void main(String[] args)  throws Exception {
		Connection con=ConClass.getConnect();
		CallableStatement stmt=con.prepareCall("{call insert_product2(?,?,?,?)}");
		stmt.setInt(1,1011);
		stmt.setString(2,"Fogg");
		stmt.setString(3,"165");
		stmt.setInt(4, 150);
		
		stmt.execute();
		
		System.out.println("success");
	}

}
