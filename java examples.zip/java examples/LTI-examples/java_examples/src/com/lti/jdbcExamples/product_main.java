package com.lti.jdbcExamples;
import java.io.IOException;
import java.sql.SQLException;
import com.lti.jdbcExamples.product_ex;
import java.util.Scanner;

public class product_main {

	public static void main(String[] args) throws SQLException, NumberFormatException, IOException {
		int n;
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter the choice");
		System.out.println("1. Create\n 2. ADD\n 3.Retrive\n 4. Update\n 5.Delete\n");
		n = sc.nextInt();
		
		 product_ex p = new product_ex();
		switch(n) {
		case 1:  p.createproduct();
				break;
				
		case 2: p.addproduct();
		break;
		
		case 3:  p.fetchproduct();
		break;
		
		case 4: p.updateproduct();
		break;
		
		case 5: p.deleteproduct();
		break;
		}
	 
		
		
	   
		
	}

}
