package com.lti.jdbcExamples;



public class Clazz implements A{
	public static void main(String args[]) {
		Clazz clazz = new Clazz();
		clazz.foo();
	}

}
