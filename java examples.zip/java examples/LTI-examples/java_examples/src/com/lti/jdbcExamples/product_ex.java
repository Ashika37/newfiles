package com.lti.jdbcExamples;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class product_ex {
	
	Statement st= null;
	Connection con=null;
	ResultSet rs =null;
	ResultSet rs1 =null;
	
	public void createproduct() throws SQLException, NumberFormatException, IOException {
	
		try {
			
			con = ConClass.getConnect();
			st = con.createStatement();
			
			String str= "create table product(product_id number(5) primary key,"
					+ " product_name varchar2(50), product_qty number(5),product_price number(5))";
			st.execute(str);
			System.out.println("created");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
			
		public void addproduct() throws SQLException, NumberFormatException, IOException{
			
			con = ConClass.getConnect();
			st = con.createStatement();
			
			PreparedStatement ps = con.prepareStatement("insert into product values(?,?,?,?)");
			BufferedReader br = new BufferedReader( new InputStreamReader(System.in));
		
			
				do {
					System.out.println("Enter product id");
					int id = Integer.parseInt(br.readLine());
					System.out.println("Enter product name");
					String name = br.readLine();
					System.out.println("Enter product quantity");
					int qty = Integer.parseInt(br.readLine());
					System.out.println("Enter product price");
					int price= Integer.parseInt(br.readLine());
					ps.setInt(1, id);
					ps.setString(2, name);
					ps.setInt(3, qty);
					ps.setInt(4,price);
					int i=ps.executeUpdate();
					System.out.println("Records affected");
					
					System.out.println("Do you want to continue:y\n");
					String s = br.readLine();
					if(s.startsWith("n")) {
						break;
					}
				}while(true);
				
				con.close();	
		}
		
		public void updateproduct() throws SQLException {
			con = ConClass.getConnect();
			st = con.createStatement();
			
			String str = "Update product set product_name='Table' where product_id=1 ";
			rs = st.executeQuery(str);
			

			String str1 = "Select * from product";
			rs1 = st.executeQuery(str1);
			while(rs1.next()) {
				System.out.println(rs1.getInt(1)+" : " + rs1.getString(2)+ " :" +rs1.getInt(3) +":" + rs1.getInt(4));
			}
				
			con.close();	
			
		}
		
		public void fetchproduct() throws SQLException {
			con = ConClass.getConnect();
			st = con.createStatement();
			
			String str = "Select * from product";
			rs = st.executeQuery(str);


			while(rs.next()) {
				System.out.println(rs.getInt(1)+" : " + rs.getString(2)+ " :" +rs.getInt(3) +":" + rs.getInt(4));
			}
			con.close();	
		}
		
		public void deleteproduct() throws SQLException, NumberFormatException, IOException {
			con = ConClass.getConnect();
			st = con.createStatement();
			
			PreparedStatement ps = con.prepareStatement("delete from product where product_id= ? ");
			BufferedReader br = new BufferedReader( new InputStreamReader(System.in));
		
			System.out.println("Enter product id");
			int id = Integer.parseInt(br.readLine());
			
			ps.setInt(1,id);
			int i=ps.executeUpdate();
			System.out.println("Records affected");
			
			con.close();	
		
		}
		
}
