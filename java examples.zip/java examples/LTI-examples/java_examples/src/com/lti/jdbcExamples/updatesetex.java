package com.lti.jdbcExamples;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class updatesetex {

	Statement st= null;
	Connection con=null;
	ResultSet rs=null;
	//ResultSet rs1=null;
	public void update() throws SQLException {
		con = ConClass.getConnect();
		st = con.createStatement();
		String str = "Update mobile11 set m_com='Orange' where m_com='Apple' ";
		rs = st.executeQuery(str);
		
		String str1 = "select * from mobile11 ";
		rs = st.executeQuery(str1);
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" : " + rs.getString(2));
		}
		
	}
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		updatesetex r = new updatesetex();
		r.update();

	}

}
