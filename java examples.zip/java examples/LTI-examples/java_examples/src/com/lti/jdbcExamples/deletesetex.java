package com.lti.jdbcExamples;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class deletesetex {

	Statement st= null;
	Connection con=null;
	ResultSet rs =null;
	public void delete() throws SQLException {
		con = ConClass.getConnect();
		st = con.createStatement();
		String str = "delete from mobile11 where m_com='Samsung' ";
		rs = st.executeQuery(str);
		
		String str1 = "select * from mobile11 ";
		rs = st.executeQuery(str1);
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" : " + rs.getString(2));
		}
	}
		
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		deletesetex r = new deletesetex();
		r.delete();
	}

}
