package com.lti.jdbcExamples;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Resultsetex {
	Statement st= null;
	Connection con=null;
	ResultSet rs =null;
	public void fetch() throws SQLException {
		con = ConClass.getConnect();
		st = con.createStatement();
		String str = "Select * from mobile11";
		rs = st.executeQuery(str);
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" : " + rs.getString(2));
		}
		
	}
	

	public static void main(String[] args) throws SQLException{
		// TODO Auto-generated method stub
		Resultsetex r = new Resultsetex();
		r.fetch();

	}

}
