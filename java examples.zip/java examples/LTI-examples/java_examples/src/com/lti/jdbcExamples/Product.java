package com.lti.jdbcExamples;

import java.sql.Connection;
import java.sql.DriverManager;

public class Product {
	
	
	Connection con= null;
	PreparedStatement ps=null;
	public void addProduct() throws SQLException,
	ClassNotFoundException {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost +":1521:XE","system","tiger");
			ps=con.prepareStatement("insert in product values" + "(p_seq")	
	}
	

}
