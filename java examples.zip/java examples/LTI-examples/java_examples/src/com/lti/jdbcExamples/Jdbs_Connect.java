package com.lti.jdbcExamples;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Jdbs_Connect {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		  System.out.println("Database example");
         Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
         System.out.println("Database connected");
         con.close();
         System.out.println("Connection closed");

	}

}
