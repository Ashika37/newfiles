package com.lti.jdbcExamples;

public interface A {
		default void foo() {
			System.out.println("Calling A.foo()");
		}
}
