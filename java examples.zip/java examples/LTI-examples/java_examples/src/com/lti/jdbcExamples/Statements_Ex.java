package com.lti.jdbcExamples;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Statement;

public class Statements_Ex {
	
	static Connection con=null;
	static Statement st=null;
	
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		try {
			System.out.println("Database Example");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
			st=con.createStatement();
			
			try {
			String str= "create table mobile11(imi number(17),m_com varchar2(30))";
			st.execute(str);
			System.out.println("created");

			}catch(Exception e) {
					e.printStackTrace();
			}
		
		String str = "insert into mobile11 values(2354678,'Samsung')";
		st.execute(str);
		String str1 = "insert into mobile11 values(23544678,'Apple')";
		st.execute(str1);
		String str2 = "insert into mobile11 values(2356578,'Nokia')";
		st.execute(str2);
		System.out.println("Data inserted");
		}catch(Exception e) {
			e.printStackTrace();
		}

	}
}
