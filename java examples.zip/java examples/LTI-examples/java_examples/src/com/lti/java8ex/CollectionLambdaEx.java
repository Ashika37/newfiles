package com.lti.java8ex;

import java.util.ArrayList;
import java.util.List;

public class CollectionLambdaEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> pointlist = new ArrayList<>();
		pointlist.add("1");
		pointlist.add("2");
		
		pointlist.forEach(p -> {
			System.out.println(p);
		});

	}

}
