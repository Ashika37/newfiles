package com.lti.java8ex;

public class MydataImpl implements MyData{
	
	public boolean isNull(String str) {
		System.out.println("Impl null check");
		return str == null ? true :false ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MydataImpl obj = new MydataImpl();
		obj.print(" ");
		obj.isNull("abc");

	}

}
