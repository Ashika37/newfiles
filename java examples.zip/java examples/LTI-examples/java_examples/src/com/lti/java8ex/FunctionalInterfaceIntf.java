package com.lti.java8ex;

@FunctionalInterface
public interface FunctionalInterfaceIntf {
	public void disp();

	@FunctionalInterface 
	interface ParamFuncInterface{
		public String show(String name);
	}
}
 