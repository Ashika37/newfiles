package com.lti.java8ex;

import com.lti.java8ex.FunctionalInterfaceIntf.ParamFuncInterface;

public class LambdaExMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Lambda Expression Implementation without parameter
		//() blank round brackets represent non_parameterized method
		String name="Shan";
		FunctionalInterfaceIntf f=() -> {System.out.println("HI "+name); };
		f.disp();
		
		//Lambda Expressions Implementation without parameter
		//(parameter) this represent for parameterized method
		
		ParamFuncInterface p =(name1)->{return "Hi " +name1;};
		System.out.println(p.show("Sachin tendulkar"));
		
		 //we can pass only parameter without using () brackets as well
		ParamFuncInterface p1 = name1 -> {return "Hi " +name1;};
		System.out.println(p1.show("Virat kohli"));

	}

}