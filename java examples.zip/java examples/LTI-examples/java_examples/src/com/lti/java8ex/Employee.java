package com.lti.java8ex;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Employee implements Comparable<Employee> {
	private int id;
	private String name;
	private double salary;
	public Employee() {
		
	}
	public Employee(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public int compareTo(Employee arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	public static void main(String args[]) {
		List<Employee> l = new ArrayList<>();
		
		l.add(new Employee (101 ,"shan", 1200.00));
		l.add(new Employee (102, "amit",1230.00));
		l.add(new Employee (103 ,"raj",1100.00));
		l.add(new Employee (10, "rajan",1270.00));
		
		System.out.println("Salary with 10% hike\n");
		l.forEach(e->e.setSalary(e.getSalary()*11/10));
		System.out.println(l);
		
		System.out.println("Salary > specific amount\n");
		List<Employee> l1=l.stream().filter(e->e.getSalary()>1300).collect(Collectors.toList());
		System.out.println(l1);
		
		System.out.println("Sorting based on name\n");
		List<Employee> l11=l.stream().sorted().collect(Collectors.toList());
		System.out.println(l11);
		
		
		}
	
}
