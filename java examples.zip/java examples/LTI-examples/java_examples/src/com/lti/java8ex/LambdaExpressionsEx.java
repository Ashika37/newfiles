package com.lti.java8ex;

public class LambdaExpressionsEx {

	public static void main(String[] args) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					System.out.println("Runnable using anonymous class");
				}			
			}).start();
			
			new Thread(
					() -> {
						System.out.println("Runnable using lambda expressions");
					}
					
					).start();
	}	

}
