package com.lti.collections;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;



public class ArrayList_ex {
	public static void main(String args[]) {
	List list = new ArrayList();
	list.add(new String("Java"));
	list.add(new Integer(22));
	list.add(new Date());
	
	Date d = (Date) list.get(2);
	System.out.println(d);
	
	 for(int i=0; i< list.size() ; i++) {
		 if(list.get(i) instanceof String) {
			 String str = (String) list.get(i);
			 System.out.println(str);
		 }
		 else if(list.get(i) instanceof Date) {
			 Date date = (Date) list.get(i);
			 System.out.println(date);
		 }
		 
		 else if(list.get(i) instanceof Integer) {
			 Integer ivalue = (Integer) list.get(i);
			 System.out.println(ivalue);
		 }
	 }
	}
}
