package com.lti.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Iterator_ex {

	public static void main(String[] args) {
		
		List<String> flavours = new ArrayList<String>();
		flavours.add("Chocolate");
		flavours.add("Strawberry");
		flavours.add("Vanilla");
		
		Collections.sort(flavours);

		Iterator<String> flavit = flavours.iterator();
		while(flavit.hasNext()) {
			System.out.println(flavit.next());
		}
	}
	
}
