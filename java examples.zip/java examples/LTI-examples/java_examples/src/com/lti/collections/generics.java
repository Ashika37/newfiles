package com.lti.collections;
import java.util.ArrayList;
import java.util.List;

public class generics {

	public static void main(String[] args) {
		List<String> strlist = new ArrayList<String>();
		strlist.add(new String("Rahul"));
		strlist.add(new String("Kavitha"));
		strlist.add(new String("Smitha"));
		
		//strlist.add(new Integer(22));
		
		for(int i=0;i<strlist.size();i++) {
				String str = strlist.get(i);
				System.out.println(str);	
				strlist.add(new String("Asha"));			
		}	
	}
}
