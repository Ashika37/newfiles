package com.lti.Book_ex;

public class Book_e implements Comparable<Book_e> {
	private long isbn;
	private int a_id;
	private int pub_id;
    private String book_title;
    
	public Book_e(long isbn, int a_id, int pub_id, String book_title) {
		this.isbn = isbn;
		this.a_id = a_id;
		this.pub_id = pub_id;
		this.book_title = book_title;
	}

	
	public long getIsbn() {
		return isbn;
	}


	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}


	public int getA_id() {
		return a_id;
	}


	public void setA_id(int a_id) {
		this.a_id = a_id;
	}


	public int getPub_id() {
		return pub_id;
	}


	public void setPub_id(int pub_id) {
		this.pub_id = pub_id;
	}


	public String getBook_title() {
		return book_title;
	}


	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}

	@Override
	public String toString() {
		return "Book_e [isbn=" + isbn + ", a_id=" + a_id + ", pub_id=" + pub_id + ", book_title=" + book_title + "]";
	}


	@Override
	public int compareTo(Book_e o) {
//	return 0;
	//return this.getA_id() - o.getA_id();
		return o.getA_id() -this.getA_id();
	}



}
