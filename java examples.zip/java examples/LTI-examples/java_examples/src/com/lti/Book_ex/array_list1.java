package com.lti.Book_ex;


import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class array_list1 {

	public static void book_info() {
		Set<book1> li = new HashSet<>();
		 li.add(new book1(12348975,1102,321,"Mossad"));
		li.add(new book1(1234455,1101,321,"Raw"));
	li.add(new book1(1784455,1103,321,"KGB"));
	li.add(new book1(1784455,1103,321,"KGB"));
	
	//Collections.sort(li, new Sortbytitle());
	
	 Iterator<book1> itr=li.iterator();
		while(itr.hasNext()) {
			book1 b = itr.next();
		System.out.println(b);
		}
	
	
	//Collections.sort(li);
	// Iterator<book1> itr1=li.iterator();
	//	while(itr1.hasNext()) {
	//		book1 b = itr1.next();
	//	System.out.println(b);
	//	}
	}

	public static void main(String[] args) {
		book_info();
	}

}
