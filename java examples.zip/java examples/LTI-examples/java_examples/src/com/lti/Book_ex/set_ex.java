package com.lti.Book_ex;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.*;

public class set_ex {
	public static void book_info() {
		Set<Book_e> li = new TreeSet<>();
		
		li.add(new Book_e(1234455,1101,321,"Raw"));
		 li.add(new Book_e(12348975,1102,321,"Mossad"));
		 li.add(new Book_e(12348975,1102,321,"Mossad"));
	      li.add(new Book_e(1784455,1103,321,"KGB"));
	
	//Collections.sort(li);
	
	 Iterator<Book_e> itr=li.iterator();
		while(itr.hasNext()) {
		Book_e b = itr.next();
		System.out.println(b);
		}
	
	
	//Collections.sort(li);
	// Iterator<Book_e> itr1=li.iterator();
	//	while(itr1.hasNext()) {
	//	Book_e b = itr1.next();
	//	System.out.println(b);
	//	}
	//}
	}
	public static void main(String[] args) {
		book_info();
	}

}



