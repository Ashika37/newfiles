package com.lti.Book_ex;

import java.util.Iterator;
import java.util.*;
	
public class book1 implements Comparable<Book_e> {
	private long isbn;
	private int a_id;
	private int pub_id;
    private String book_title;
    
	public book1(long isbn, int a_id, int pub_id, String book_title) {
		this.isbn = isbn;
		this.a_id = a_id;
		this.pub_id = pub_id;
		this.book_title = book_title;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + a_id;
		result = prime * result + ((book_title == null) ? 0 : book_title.hashCode());
		result = prime * result + (int) (isbn ^ (isbn >>> 32));
		result = prime * result + pub_id;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		book1 other = (book1) obj;
		if (a_id != other.a_id)
			return false;
		if (book_title == null) {
			if (other.book_title != null)
				return false;
		} else if (!book_title.equals(other.book_title))
			return false;
		if (isbn != other.isbn)
			return false;
		if (pub_id != other.pub_id)
			return false;
		return true;
	}


	public long getIsbn() {
		return isbn;
	}


	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}


	public int getA_id() {
		return a_id;
	}


	public void setA_id(int a_id) {
		this.a_id = a_id;
	}


	public int getPub_id() {
		return pub_id;
	}


	public void setPub_id(int pub_id) {
		this.pub_id = pub_id;
	}


	public String getBook_title() {
		return book_title;
	}


	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}

	@Override
	public String toString() {
		return "book1 [isbn=" + isbn + ", a_id=" + a_id + ", pub_id=" + pub_id + ", book_title=" + book_title + "]";
	}


	@Override
	public int compareTo(Book_e o) {
//	return 0;
	//return this.getA_id() - o.getA_id();
		return o.getA_id() -this.getA_id();
	}



}


