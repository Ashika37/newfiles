package com.lti.Book_ex;
import java.util.Comparator;

public class Sortbytitle implements Comparator<Book_e>{

	@Override
	public int compare(Book_e o1, Book_e o2) {
	return o1.getBook_title().compareTo(o2.getBook_title());
	}
}

