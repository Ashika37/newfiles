package com.lti.javaexamples1;

public class Vehicle1 implements Engine {
	
	int speed;
	int gear;
	
	
	
	
	

}
