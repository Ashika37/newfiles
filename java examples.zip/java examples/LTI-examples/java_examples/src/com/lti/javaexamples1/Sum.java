package com.lti.javaexamples1;

abstract class Sum {
	
	public abstract int sumOfTwo(int n1,int n2);
	public abstract int sumOfThree(int n1,int n2, int n3);
	
	public void disp() {
		System.out.println("Method of class Sum");
	}
}
