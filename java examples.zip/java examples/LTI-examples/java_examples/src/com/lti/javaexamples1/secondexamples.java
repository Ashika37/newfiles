package com.lti.javaexamples1;

import com.lti.javaexamples.firstexample;

public class secondexamples {

	public static void main(String[] args) {
		System.out.println("Default package implemented in other package");
		firstexample f = new firstexample();

	}

}

