package com.lti.javaexamples1;
import java.util.Scanner;
 public class Matrix{
	 
public void matrix_add() {//if by mistake we add any character, it should start again from the begining
	try {
			System.out.println("Matrix addition");
			Scanner ad = new Scanner(System.in);
			int m=1,n=1;
			System.out.println("Enter the number of rows and column ");
			m = ad.nextInt();
			n = ad.nextInt();
			
			int A[][] = new int[m][n];
			int B[][] = new int[m][n];
			int sum[][] = new int[m][n];
			
			System.out.println("Enter the elements of matrix A");
			
			for(int i=0;i<m;i++) {
				for(int j=0;j<n;j++) {
					A[i][j] = ad.nextInt();
				}
			}
			
			System.out.println("Enter the elements of matrix B");
			for(int i=0;i<m;i++) {
				for(int j=0;j<n;j++) {
					B[i][j] = ad.nextInt();
				}
			}
			
			for(int i=0;i<m;i++) {
				for(int j=0;j<n;j++) {
					sum[i][j] = A[i][j]+B[i][j]  ;
				}
			}
			
			System.out.println("Sum of matrix A and B");
			for(int i=0;i<m;i++) {
				for(int j=0;j<n;j++) {
					System.out.println(sum[i][j] + "\t");
					System.out.println();
				}
			}
			
		}catch(Exception e) {
			System.out.println("NO ALPHABETS...");
			matrix_add();
			
		}
		}
public static void main(String args[]) {
	Matrix m=new Matrix();
	m.matrix_add();
}


 }