package com.lti.javaexamples1;

public class Add_Ex {
     public Add_Ex() {}
     public Add_Ex(int a, int b) {
    	  System.out.println(a+b);
     }
	public Add_Ex(double a, double b) {
		System.out.println(a-b);
	}
	
	public static void main(String[] args) {
		Add_Ex a = new Add_Ex();
		Add_Ex b = new Add_Ex(1,2);
		Add_Ex c = new Add_Ex(9.33,5.4);
		
	}
}
