package com.lti.javaexamples1;
import java.io.*;

public class ThrowsDemo {
	static void throwOne() throws
	FileNotFoundException{
		System.out.println("Inside ThrowOne.") ;
		throw new FileNotFoundException();
}
	
	public static void main  (String args[]) {
		try {
			throwOne();
			}
		catch (FileNotFoundException e){
			System.out.println("Caught"  + e);
	}
	}
}