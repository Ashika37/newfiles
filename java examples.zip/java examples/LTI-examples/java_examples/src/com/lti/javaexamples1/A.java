package com.lti.javaexamples1;

 interface C{
	 public void method() ;
}
 interface B {
	 public void method();
}
 
 class F implements C,B{
	 public void method() {
		 System.out.println("Hi from Sub Class");
	 }
 }

 public class A {
	 public static void main(String args[]) {
		 B b=new F();
		 b.method();
		 
	 }
 }