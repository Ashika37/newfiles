package com.lti.javaexamples1;
import java.util.Scanner;
	
public class assignment {

	public static void main(String[] args) {
		assignment1 a = new assignment1();
		int n;
		System.out.println("Select from the option");
		System.out.println("1.Fibonacci \n 2. Palindrome \n 3.Prime number \n 4. Matrix addition \n 5. Matrix multiplication\n");
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		switch(n) {
		
		case 1 : a.fibonacci() ;
			break;
			
		case 2 : a.Palindrome();
			break;
			
		case 3 : a.Prime_number();
			break;
			
		case 4 : a.matrix_add() ;
			break;
			
		case 5 : a.matrix_mul();
			break;
		
		}
	}
}


