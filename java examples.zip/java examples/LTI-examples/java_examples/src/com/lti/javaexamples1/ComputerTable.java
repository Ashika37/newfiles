package com.lti.javaexamples1;

public class ComputerTable {
	public  ComputerTable() {}
	public  ComputerTable( double width, double breadth, double length) {
		System.out.println("Width =" +width + "\t breadth=" + breadth+ "\t length=" + length);
		double area = width*breadth*length;
		System.out.println(" Area is" +area);
		double perimeter = width+breadth+length;
		System.out.println("Perimeter =" + perimeter);
		 
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ComputerTable c= new ComputerTable (3 , 4, 2.5);

	}

}
