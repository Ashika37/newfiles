package com.lti.javaexamples1;

import java.util.Scanner;

public class assignment1 {
		
		public void fibonacci() {
			System.out.println("Fibonacci series ");
			int n1=0,n2=1,count;
			System.out.println("Enter the limit for finobanacci series ");
			Scanner c = new Scanner(System.in);
			count = c.nextInt();
			System.out.println(+n1 + " " +n2);
			for(int i=2;i<count;++i) {
				int n3 = n1+n2 ;
				System.out.println(" "+n3);
				n1=n2;
				n2=n3;
			}
		}

		public void Palindrome() {	
			System.out.println("Palindrome ");
			String s1,rev="";
			int i=0 ;
			System.out.println("Enter the string ");
			Scanner str = new Scanner(System.in);
			s1 = str.nextLine();
			int len = s1.length();
			
			for( i = len-1;i>=0;i--) {
				rev = rev + s1.charAt(i);
			}
			if(s1.equals(rev)) {
				System.out.println("It is a palindrome ");
			}
			else
			{
				System.out.println("It is not a palindrome ");
			}
		}

		public void Prime_number() {
	
			System.out.println("Prime numbers");
			int n1 , flag =0 ,m=0;
			System.out.println("Enter the number of prime numbers to be displayed ");
			Scanner c1 = new Scanner(System.in);
			n1 = c1.nextInt();
			m = n1/2;
			if(n1 == 0 || n1 ==1) {
				System.out.println(n1 + " It is not a Prime numbers");
			}
			else {
				for(int i=2;i<=m;i++) {
					if( n1 % i == 0) {
						System.out.println(n1 + " It is not a Prime numbers");
						flag =1;
							break;
					}
				}
			
				if(flag==0) {
					System.out.println(n1 + " It is a Prime numbers");
				}
			}
			
		}

		public void matrix_add() {
	
			System.out.println("Matrix addition");
			Scanner ad = new Scanner(System.in);
			int m,n;
			System.out.println("Enter the number of rows and column ");
			m = ad.nextInt();
			n = ad.nextInt();
			
			int A[][] = new int[m][n];
			int B[][] = new int[m][n];
			int sum[][] = new int[m][n];
			
			System.out.println("Enter the elements of matrix A");
			for(int i=0;i<m;i++) {
				for(int j=0;j<n;j++) {
					A[i][j] = ad.nextInt();
				}
			}
			
			System.out.println("Enter the elements of matrix B");
			for(int i=0;i<m;i++) {
				for(int j=0;j<n;j++) {
					B[i][j] = ad.nextInt();
				}
			}
			
			for(int i=0;i<m;i++) {
				for(int j=0;j<n;j++) {
					sum[i][j] = A[i][j]+B[i][j]  ;
				}
			}
			
			System.out.println("Sum of matrix A and B");
			for(int i=0;i<m;i++) {
				for(int j=0;j<n;j++) {
					System.out.println(sum[i][j] + "\t");
					System.out.println();
				}
			}
			
		}
		public void matrix_mul() {
			
			System.out.println("Matrix maultiplication");
			Scanner mu = new Scanner(System.in);
			int m,n;
			System.out.println("Enter the number of rows and column ");
			m = mu.nextInt();
			
			int A[][] = new int[m][m];
			int B[][] = new int[m][m];
			int mul[][] = new int[m][m];
			
			System.out.println("Enter the elements of matrix A");
			for(int i=0;i<m;i++) {
				for(int j=0;j<m;j++) {
					A[i][j] = mu.nextInt();
				}
			}
			
			System.out.println("Enter the elements of matrix B");
			for(int i=0;i<m;i++) {
				for(int j=0;j<m;j++) {
					B[i][j] = mu.nextInt();
				}
			}
			
		
			for(int i=0;i<m;i++) {
				for(int j=0;j<m;j++){
					for (int k=0;k<m;k++) {
						mul[i][j] = mul[i][j] + A[i][k] * B[k][j];	
					}
				}
			}
			
			System.out.println("Resultant matrix is");
			for(int i=0;i<m;i++) {
				for(int j=0;j<m;j++) {
					System.out.println(mul[i][j] + " ");
				}
				System.out.println();
			}
		}
}
	
