package com.lti.javaexamples1;

     class Vehicle {
    	 public void start() {
    		 System.out.println("Start Method");
    	 }
        public void stop() {
        	System.out.println("Stop Method For vehicle :");
        	
        } 
        public void turn(String direction) {
        	System.out.println("Turn Method for Vehicle :" + direction);
        }
}

     
 class Bike extends Vehicle{
	 public void start () {
		 System.out.println("Start Method For Bike");
     	 }
	 public void stop() {
		 System.out.println("Stop Method For Bike");
     	
	 }
 }