package com.lti.javaexamples1;

public interface Engine {
	void changeGear(int a);
	void speedUp(int a);

}
