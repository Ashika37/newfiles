package com.lti.javaexamples1;
import java.util.Scanner;

public class Rectangle {

	public Rectangle() {
			 int len1,wid1;
			 len1=1;
			 wid1=1;
			 System.out.println("Length and width are " + len1 +"\t" + wid1);
			 int area = len1*wid1;
			 System.out.println("Area is " +area);
	}
	
	 public Rectangle(int l1, int w1) {	
			 int ln2=l1;
			 int wi2=w1;
			 System.out.println("Length and width are " + ln2 +"\t" + wi2);
			 int area2 = ln2*wi2;
			 System.out.println("Area is " +area2); 
	 }

	public static void main(String[] args) {
		System.out.println("Do you want to enter the dimension(1/0)");
		int n;
		Scanner m = new Scanner(System.in);
		n=m.nextInt();
		if(n == 1) {
			Scanner len = new Scanner(System.in);
			Scanner wid = new Scanner(System.in);
			int length,width;
	      System.out.println("Enter length and width of rectangle");
	      length = len.nextInt();
	      width = wid.nextInt();  
	      Rectangle r1 = new Rectangle(length,width);
		}
		else
		{
			System.out.println("Automatic Initialisation");
			Rectangle r = new Rectangle();
		}
		
		// TODO Auto-generated method stub
		
   
      
      
	}

}
