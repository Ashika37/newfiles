package com.lti.javaexamples1;

public class static_ex {
	static int i=10;
	static int j=10;
	static {
		int k=90;
		System.out.println("Static block invoked" +(i+j+k));
	}
	
	public static void display() {
		System.out.println("Static method invoked invoked" +(i+j));
	}
	public static void main(String args[]) {
		System.out.println("Static main method invoked after static block " +(i+j));
		display();
				}
}
