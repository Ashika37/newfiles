package com.lti.javaexamples1;

public class VehicleMain {
	public static void main(String[] args) { 
		Vehicle v = new Vehicle();
		v.turn("right");
		
		Bike b = new Bike();
		b.turn("left");
		b.start();
		b.stop();
	}

}
