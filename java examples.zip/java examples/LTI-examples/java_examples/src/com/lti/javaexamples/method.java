package com.lti.javaexamples;

class method_ex{
	private int a;
	private int b;
	public void add(int a,int b) {
		this.a=a;
		this.b=b;
		System.out.println(a+b);
	}
	public int substract(int i,int j) {
		this.a=i;
		this.b=j;
		return i-j;
	}
}



public class method {
	public static void main(String[] args) {
		method_ex m = new method_ex();
		m.add(10,20);
		System.out.println(m.substract(20,30));
	}

}
