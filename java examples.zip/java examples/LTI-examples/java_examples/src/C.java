
public class C  implements ar , im
{
	
	    public static void main(String[] args)
	    {
	        System.out.println(new C().getGreeting());
	    }

		@Override
		public String getGreeting() {
			// TODO Auto-generated method stub
			return 
					
					
					
					
					
					
					im.super.getGreeting();
		}
	}

