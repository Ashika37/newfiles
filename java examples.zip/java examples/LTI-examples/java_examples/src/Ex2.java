
public class Ex2 {
	public static void main(String args[]) {
		try {
			int i= Integer.parseInt(args[0]);
			System.out.println(i);
		
	}
	//System.out.println("Testing");
	catch(NumberFormatException e) {
		System.out.println(Exception e) {
	}}
}
