
public interface im {
	
    default String getGreeting() {
        return "Good Morning!";
    }
}

