
public interface ar {
	
	    default String getGreeting() {
	        return "Good Afternoon!";
	    }

	}



