package com.lti.minipro1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Implementationclass {

	public void Year() throws IOException {

		}
	
	public void Nameofbank() throws IOException {
		
		System.out.println("Enter the Name of the bank");
		Scanner c1 = new Scanner(System.in);
		String line1 = c1.next();
		
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\pcuser\\Desktop\\OneDrive_1_10-15-2019\\complaints.csv"));
		String line;
		while ((line = br.readLine()) != null) {
		    String[] cols = line.split(",");
		    if(cols[5].equalsIgnoreCase(line1)) {
	         System.out.println("Coulmn 1 = " + cols[5] +" " +" Column 2 " + cols[1]);
		    }
		}
		
	}
	
	public void ComplaintId() throws IOException {
		System.out.println("Enter the Complaint Id");
		Scanner c1 = new Scanner(System.in);
		String line1 = c1.next();
		
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\pcuser\\Desktop\\OneDrive_1_10-15-2019\\complaints.csv"));
		String line;
		while ((line = br.readLine()) != null) {
		    String[] cols = line.split(",");
		    if(cols[13].equalsIgnoreCase(line1)) {
	         System.out.println("Coulmn 1 = " + cols[13]+" " +" Column 2 " + cols[1] + " " +cols[3]);
		    }
		}
		
	}
	
	public void Noofdays() throws IOException {
		
	}
	
	public void Closed() throws IOException {

		String c4="closed with explanation";
		String c5="closed";
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\pcuser\\Desktop\\OneDrive_1_10-15-2019\\complaints.csv"));
		String line;
			while ((line = br.readLine()) != null) {
			    String[] cols = line.split(",");
			    if(cols[10].equalsIgnoreCase(c4))
			    {
			    System.out.println("Complaints are =   " + cols[3] );
			    }

			}
			while ((line = br.readLine()) != null) {
			    String[] cols = line.split(",");
			    if(cols[10].equalsIgnoreCase(c5))
			    { 
			    System.out.println("Complaints are =   " + cols[3] );  
			    }

			}
			
	}
	
	public void Timely() throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\pcuser\\Desktop\\OneDrive_1_10-15-2019\\complaints.csv"));
		String line;
		while ((line = br.readLine()) != null) {
		    String[] cols = line.split(",");
		     if( cols[11].equalsIgnoreCase("Yes")) {
	  	       System.out.println("Coulmn 1 = " + cols[11] +" " + "Coulmn 2 = " + cols[3]);
	         
		    }
		}
	}
	
	public void Inputstoring() throws IOException {
		
	}
}



