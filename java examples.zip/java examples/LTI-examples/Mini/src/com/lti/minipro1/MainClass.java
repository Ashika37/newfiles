package com.lti.minipro1;

import java.io.IOException;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) throws IOException {
		Implementationclass l = new Implementationclass();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the choice \n");
		System.out.println("1.Year \n 2. Name of Bank \n 3. Complaint Id \n 4. Days \n 5.Closed \n 6. Received\n 7. Input\n");
		int n = sc.nextInt();
		switch(n) {
		case 1:l.Year();
			break;
			
		case 2:l.Nameofbank();
			break;
			
		case 3:l.ComplaintId();
			break;
			
		case 4:l.Noofdays();
			break;
			
		case 5:l.Closed();
			break;
			
		case 6:l.Timely();
			break;
			
		case 7:l.Inputstoring();
			break;
		}

	}

}
