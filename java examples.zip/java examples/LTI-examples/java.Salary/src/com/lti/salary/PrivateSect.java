package com.lti.salary;


public class PrivateSect implements Salary {
	double basic,salary,hra,da;
	@Override
	public void salDetails(double basic) {
		this.basic=basic;
	hra=0.5*basic;
	da=0.1*basic;
	salary=basic+hra+da;
		System.out.println("Gross salary private sector is:"+basic);
		System.out.println("Net salary  private sector is :"+salary);
	}
	

}
