package com.lti.salary;


public class StateGovt implements Salary {
double basic,salary,hra,da;
	@Override
	public void salDetails(double basic) {
		this.basic=basic;
	hra=2.5*basic;
	da=0.3*basic;
	salary=basic+hra+da;
		System.out.println("Gross salary of State Govt is:"+basic);
		System.out.println("Net salary of State Govt is :"+salary);
	}
	

}