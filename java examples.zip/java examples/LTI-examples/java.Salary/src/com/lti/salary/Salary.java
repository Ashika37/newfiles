package com.lti.salary;

public interface Salary {
void salDetails(double basic);

}

