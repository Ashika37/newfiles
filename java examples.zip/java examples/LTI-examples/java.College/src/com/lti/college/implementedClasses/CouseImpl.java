package com.lti.college.implementedClasses;
import com.lti.CollegeDetails.beanClass.CourseBean;

import com.lti.CollegeDetails.beanClass.InstructorBean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.lti.college_interfaces.CourseInterface;


public class CouseImpl implements CourseInterface{

	Statement st=null;
	Connection con = null;
	//ResultSet rs = null;
	CourseBean cb = new CourseBean();
	InstructorBean ib1 = new InstructorBean();
	Scanner scan = new Scanner(System.in);
	String a =" ";
	@Override
	public void addCourse() {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
			
			PreparedStatement ps = con.prepareCall("insert into Course7 values(?,?,?,?,?)");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
			do {
			System.out.println("Enter course Number");
			cb.setCourseno(Integer.parseInt(br.readLine()));
			System.out.println("Enter course Name");
			cb.setCname(br.readLine()); 
			System.out.println("Enter course Duration");
			cb.setDuration(br.readLine());
			System.out.println("Enter course Pre-requiste");
			cb.setPrerequisite( br.readLine());
			System.out.println("Enter Instructor id ");
			ib1.setIid(Integer.parseInt(br.readLine()));
			
			ps.setInt(1, cb.getCourseno());
			ps.setString(2, cb.getCname());
			ps.setString(3, cb.getDuration());
			ps.setString(4, cb.getPrerequisite());
			ps.setInt(5, ib1.getIid());
			
			int rows = ps.executeUpdate();
			
			System.out.println("Records Added\n");
			System.out.println("Do you want to add the records(y/n)\n");
			a= scan.next();
			
			}while(a.equals("y") );

			con.close();
			}catch(Exception e) {
			e.printStackTrace();
			}
	}
	

	@Override
	public void displayCourse() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
			
			Statement st1 = con.createStatement();
			String sqlsentence2 = "SELECT * FROM Course7";
            PreparedStatement st2 = con.prepareStatement(sqlsentence2);
            ResultSet rs = st2.executeQuery();
            
			while(rs.next()) {
			System.out.println("");
			System.out.println(rs.getInt(1) + ":\t" + rs.getString(2) + ":\t" + rs.getInt(3) +":\t" + rs.getString(4)+ ":\t" + rs.getInt(5));
			}
			con.close();
			}catch(Exception e) {
			e.printStackTrace();
			}
		
	}

	@Override
	public void deleteCourse() {
		// TODO Auto-generated method stub
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
			ResultSet rs = null;
			st = con.createStatement();
			
			PreparedStatement ps = con.prepareCall("delete from Course7 where courseno =?");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter Course Number");
			cb.setCourseno(Integer.parseInt(br.readLine()));
			ps.setInt(1, cb.getCourseno());
			int i=ps.executeUpdate();
			System.out.println("Deletion complete\n");
			con.close();
			}catch(Exception e) {
			e.printStackTrace();
			}
		
	}

	@Override
	public void updateCourse() {
		// TODO Auto-generated method stub
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
			ResultSet rs = null;
			st = con.createStatement();
			
			PreparedStatement ps = con.prepareCall("UPDATE Course7 SET cname  = ? WHERE courseno = ? ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			do {
			
			
			System.out.println("Enter Course Name");
			cb.setCname(br.readLine()); 
			ps.setString(1, cb.getCname());
			
			System.out.println("Enter Course Number");
			cb.setCourseno(Integer.parseInt(br.readLine()));
			ps.setInt(2, cb.getCourseno());
			
			int i=ps.executeUpdate();
			System.out.println("Do you want to add the records(y/n)\n");
			a= scan.next();
			System.out.println("Updation complete\n");
			con.close();
			}while(a.equals("y") );

			}catch(SQLException e1) {
				e1.printStackTrace();
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} 
	}
}




