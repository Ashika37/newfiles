package com.lti.college.implementedClasses;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.lti.CollegeDetails.beanClass.DepartmentBean;
import com.lti.CollegeDetails.beanClass.InstructorBean;
import com.lti.college_interfaces.InstInterface;

public class InstImpl implements InstInterface{
	Statement st=null;
	Connection con = null;
	ResultSet rs = null;
	InstructorBean ib2 = new InstructorBean();
	DepartmentBean db2 = new DepartmentBean();
	Scanner scan = new Scanner(System.in);
	String a =" ";
	@Override
	public void addInstructor() {
		// TODO Auto-generated method stub
	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
		
		
			PreparedStatement ps = con.prepareCall("insert into Instructor7 values(?,?,?,?)");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			do {
			System.out.println("Enter Instructor Number");
			ib2.setIid(Integer.parseInt(br.readLine()));
			
			System.out.println("Enter Instructor Name");
			ib2.setIname(br.readLine());
			
			System.out.println("Enter Instructor Room");
			ib2.setRoom(br.readLine());
			
			System.out.println("Enter Department Number");
			db2.setDnumber(Integer.parseInt(br.readLine()));
			ps.setInt(1, ib2.getIid());
			ps.setString(2, ib2.getIname());
			ps.setString(3, ib2.getRoom());
			ps.setInt(4,db2.getDnumber());
			int rows = ps.executeUpdate();
			
			System.out.println("Records Added\n");
			System.out.println("Do you want to add the records(y/n)\n");
			a= scan.next();
			}while(a.equals("y"));
			con.close();
		}catch(Exception e) {
			e.printStackTrace();
			}
	}

	@Override
	public void displayInstructor() {
		// TODO Auto-generated method stub
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
			
			Statement st1 = con.createStatement();
			String sqlsentence2 = "SELECT * FROM Instructor7";
            PreparedStatement st2 = con.prepareStatement(sqlsentence2);
            ResultSet rs = st2.executeQuery();
 
			while(rs.next()) {
			System.out.println(rs.getInt(1) + "  :\t" + rs.getString(2) + "  :\t" + rs.getString(3) + "  :\t" + rs.getString(4));
			}
			con.close();
			}catch(Exception e) {
			e.printStackTrace();
			}
		
	}

	@Override
	public void deleteInstructor() {
		// TODO Auto-generated method stub
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
			
			PreparedStatement ps = con.prepareCall("delete from Instructor7 where iid =?");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter Instructor Number");
			ib2.setIid(Integer.parseInt(br.readLine()));
			ps.setInt(1, ib2.getIid());
			int i=ps.executeUpdate();
			System.out.println("Deletion complete\n");
			con.close();
			}catch(Exception e) {
			e.printStackTrace();
			}
		
	}

	@Override
	public void updateInstructor() {
		// TODO Auto-generated method stub
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
			ResultSet rs = null;
			st = con.createStatement();
			
			PreparedStatement ps = con.prepareCall("UPDATE Instructor7 SET iname  = ? WHERE iid = ? ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			do {
				System.out.println("Enter Instructor Name");
				ib2.setIname(br.readLine());
				ps.setString(1, ib2.getIname());
			
				System.out.println("Enter Instructor Number");
				ib2.setIid(Integer.parseInt(br.readLine()));
				ps.setInt(2, ib2.getIid());
	
			
				int i=ps.executeUpdate();
				System.out.println("Do you want to add the records(y/n)\n");
				a= scan.next();
				System.out.println("Updation complete\n");
				con.close();
				}while(a.equals("y") );
			}catch(SQLException e1) {
				e1.printStackTrace();
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} 
			}
	}

