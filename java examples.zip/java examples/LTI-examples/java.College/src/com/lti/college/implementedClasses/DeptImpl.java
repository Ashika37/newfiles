package com.lti.college.implementedClasses;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.lti.CollegeDetails.beanClass.DepartmentBean;
import com.lti.college_interfaces.DeptInterface;

public class DeptImpl implements DeptInterface {

	Statement st=null;
	Connection con = null;
	ResultSet rs = null;
	DepartmentBean db = new DepartmentBean();
	Scanner scan = new Scanner(System.in);
	String a =" ";
	@Override
	public void addDept() {
		// TODO Auto-generated method stub
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
		
		
			PreparedStatement ps = con.prepareCall("insert into Department7 values(?,?,?)");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			do {
			System.out.println("Enter Department Number");
			db.setDnumber(Integer.parseInt(br.readLine()));
			
			System.out.println("Enter Department Name");
			db.setDname(br.readLine());
			
			System.out.println("Enter Department Location");
			db.setLocation(br.readLine());
			
			ps.setInt(1, db.getDnumber());
			ps.setString(2, db.getDname());
			ps.setString(3, db.getLocation());
			
			int rows = ps.executeUpdate();
			
			System.out.println("Records Added\n");
			System.out.println("Do you want to add the records(y/n)\n");
			a= scan.next();
			}while(a.equals("y"));
			con.close();
		}catch(Exception e) {
			e.printStackTrace();
			}
	}

	@Override
	public void displayDept() {
		// TODO Auto-generated method stub
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
			
			Statement st1 = con.createStatement();
			String sqlsentence2 = "SELECT * FROM Department7";
            PreparedStatement st2 = con.prepareStatement(sqlsentence2);
            ResultSet rs = st2.executeQuery();

			while(rs.next()) {
			System.out.println("");
			System.out.println(rs.getInt(1) + ":\t" + rs.getString(2) + ":\t" + rs.getString(3));
			}
			con.close();
			}catch(Exception e) {
			e.printStackTrace();
			}
		
	}

	@Override
	public void deleteDept() {
		// TODO Auto-generated method stub
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
		
			PreparedStatement ps = con.prepareCall("delete from Department7 where dnumber=?");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter Department Number");
			db.setDnumber(Integer.parseInt(br.readLine()));
			ps.setInt(1, db.getDnumber());
			int i=ps.executeUpdate();
			System.out.println("Deletion complete\n");
			con.close();
			}catch(Exception e) {
			e.printStackTrace();
			}
		
	}

	@Override
	public void updateDept() {
		// TODO Auto-generated method stub
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
			ResultSet rs = null;
			st = con.createStatement();
			
			PreparedStatement ps = con.prepareCall("UPDATE Department7 SET location  = ? WHERE dnumber = ? ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			do {
		
			System.out.println("Enter Department Location");
			db.setLocation(br.readLine());
			ps.setString(1, db.getLocation());
				
			System.out.println("Enter Department Number");
			db.setDnumber(Integer.parseInt(br.readLine()));
			ps.setInt(2, db.getDnumber());

			int i=ps.executeUpdate();
			System.out.println("Do you want to add the records(y/n)\n");
			a= scan.next();
			System.out.println("Updation complete\n");
			con.close();
			}while(a.equals("y") );
		}catch(SQLException e1) {
			e1.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
		}
		
	}





