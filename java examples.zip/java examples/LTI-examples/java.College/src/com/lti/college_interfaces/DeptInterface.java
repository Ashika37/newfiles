package com.lti.college_interfaces;

public interface DeptInterface {
	void addDept();
	void displayDept();
	void deleteDept();
	void updateDept();
	

}
