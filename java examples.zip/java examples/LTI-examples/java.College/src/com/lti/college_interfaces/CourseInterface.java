package com.lti.college_interfaces;

public interface CourseInterface {

	void addCourse();
	void displayCourse();
	void deleteCourse();
	void updateCourse();
	
}
