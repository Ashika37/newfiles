package com.lti.college_interfaces;

public interface InstInterface {
	void addInstructor();
	void displayInstructor();
	void deleteInstructor();
	void updateInstructor();
	

}
