package com.lti.CollegeDetails.beanClass;


public class DepartmentBean {

	private int dnumber;
	private String dname;
	private String location;
	public  DepartmentBean() {}
	public DepartmentBean(int dnumber, String dname, String location) {
		this.dnumber = dnumber;
		this.dname = dname;
		this.location = location;
	}
	public int getDnumber() {
		return dnumber;
	}
	public void setDnumber(int dnumber) {
		this.dnumber = dnumber;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "DepartmentBean [dnumber=" + dnumber + ", dname=" + dname + ", location=" + location + "]";
	}
	
}














