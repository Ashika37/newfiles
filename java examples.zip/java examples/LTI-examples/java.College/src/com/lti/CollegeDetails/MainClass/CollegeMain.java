package com.lti.CollegeDetails.MainClass;

import com.lti.college.implementedClasses.*;


import java.util.InputMismatchException;
import java.util.Scanner;

import java.io.*;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.*;



public class CollegeMain {

	public static void main(String[] args) throws SQLException, NumberFormatException ,IOException {
		
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the choice \n");
			System.out.println("1.Course \n 2. Department \n 3. Instructor\n 4. Student\n");
			int n = sc.nextInt();
			switch(n) {
			case 1: try {
			System.out.println("Enter the choice \n");
			System.out.println("1.Add Course \n 2.Update Course  \n 3.Delete Course \n 4.Display Course \n");
			int a = sc.nextInt();
			CouseImpl c = new CouseImpl();
			switch(a) {
			case 1:c.addCourse();
			break;
			case 2:c.updateCourse();
			break;
			case 3:c.deleteCourse();
			break;
			case 4:c.displayCourse();
			break;
			}
			}catch(Exception e) {
			System.out.println("Error\n");
			}
			break;
			case 2:try {
			System.out.println("Enter the choice \n");
			System.out.println("1.Add Department \n 2.Update Department  \n 3.Delete Department \n 4.Display Department \n");
			int a = sc.nextInt();
			DeptImpl c = new DeptImpl();
			switch(a) {
			case 1:c.addDept();
			break;
			case 2:c.updateDept();
			break;
			case 3:c.deleteDept();
			break;
			case 4:c.displayDept();
			break;
			}

			}catch(Exception e) {
			System.out.println("Error\n");
			}
			break;
			case 3:try {
			System.out.println("Enter the choice \n");
			System.out.println("1.Add Instructor \n 2.Update Instructor  \n 3.Delete Instructor \n 4.Display Instructor \n");
			int a = sc.nextInt();
			InstImpl c = new InstImpl();
			switch(a) {
			case 1:c.addInstructor();
			break;
			case 2:c.updateInstructor();
			break;
			case 3:c.deleteInstructor();
			break;
			case 4:c.displayInstructor();
			break;
			}

			}catch(Exception e) {
			System.out.println("Error\n");
			}
			break;
			case 4:try {
			System.out.println("Enter the choice \n");
			System.out.println("1.Add Student \n 2.Update Student  \n 3.Delete Student \n 4.Display Student \n");
			int a = sc.nextInt();
			StudentImpl c = new StudentImpl();
			switch(a) {
			case 1:c.addStud();
			break;
			case 2:c.updateStud();
			break;
			case 3:c.deleteStud();
			break;
			case 4:c.displayStud();
			break;
			}

			}catch(Exception e) {
			System.out.println("Error\n");
			}
			break;
			}
			}
	
	
	}
		//DepartmentBean db1=new DepartmentBean(101,"CS","Mumbai");
		//InstructorBean ib=new InstructorBean(012,"Shan","1101",db1);
		//CourseBean cb=new CourseBean(123,"JAVA","40","ApplicationDevelopment", ib);
		//StudentBean sb=new StudentBean(1,"abc","18Nov1997",cb,ib);
		
		//System.out.println(ib);
		//System.out.println(cb);
		//System.out.println(sb);
		//DepartmentBean db=ib.getDb();

