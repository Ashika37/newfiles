package com.lti.miniproject;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Iterator;
import java.util.List;

public class Complaint {
	importfile i = new importfile();
	
	public void Complaintyear() {
				
		//System.out.print(i.li);
	}
	
	public void Nameofbank() {
		
	}

	public void ComplaintId() {
		
	}
}




 
