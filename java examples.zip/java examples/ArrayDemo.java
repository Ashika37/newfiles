public class ArrayDemo{
 public static void main(String args[]){
  int[] x = {3,5,8,3,7,55,55,46};  //declares an array of integers
	for(int i =0 ; i < x.length ;i++){
	System.out.println(x[i]);
	}
	String[] namearr = {"Hello","Worlds"};

	for(int i =0 ; i < namearr.length ;i++){		//use for loop to iterate string array
		System.out.println(namearr[i]);
	}
	for (String temp : namearr)
	{
		System.out.println(temp);
	}
}
}