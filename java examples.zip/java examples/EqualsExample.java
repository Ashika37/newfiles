class EqualsExample{
public static void main(String h[]){
int i=10;
int j=10;
String str1="Hello";
String str2="Hello";
String str3= new String("Hello");

System.out.println(i==j);
System.out.println(i!=j);

System.out.println(str1==str2);
System.out.println(str1==str3);
System.out.println(str1..equals(str3));
}
}