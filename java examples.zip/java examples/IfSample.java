import java.util.Scanner;
public class IfSample{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
int x,y;
System.out.println("Enter the value of x and y: ");
x = sc.nextInt();             //predefined Method i Scanner class for inserting integer values
y = sc.nextInt();             //similarly we have methods for float as nextFloat and double as nextDouble and 
                              //for string we have methods as next() or nextLine()

if(x<y) System.out.println("x is less then y");
x = x*2;
if(x == y) System.out.println("x is now equal  y");
x = x*2;
if(x > y) System.out.println("x is now greater than y");
}
}

