public class Samples
{
int i.=10; //instance variable
static int j=20; //class variable
public static void main(String args[]){
String str="LTI" ; //local variable
System.out.println("Instance Variable Value is: "+new Samples().i+"Class Variable Value is : "+j+"local variable value is" +str);
}
}