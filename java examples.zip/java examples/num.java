public class num{
public static void main(String args[]){
long ccn=1234_5678_9012_3456L;
long ssn=999_99_9999L;
float pi=3.14_15F;
System.out.println("n="+ccn);
System.out.println("n="+ssn);
System.out.println("n="+pi);
}
}