import java.util.Scanner;
public class Salary{
public static void main(String args[]){
Scanner sc= new Scanner(System.in);
Double c, a, g;

System.out.println("Enter the salary of clerk (10000-15000)");
c = sc.nextDouble();  

System.out.println("Enter the salary of As. Manager(20000-25000)");
a = sc.nextDouble();  

System.out.println("Enter the salary of G. Manager(30000-40000)");
g = sc.nextDouble();  


if (10000 < c && c < 12000) 
c = c + (0.1*c) ;
System.out.println("new salary of clerk" + c);

if (20000 < a && a < 23000) 
a = a + (0.15*a) ;
System.out.println("new salary of As. Manager" + a);

if (30000 < g && g < 36000) 
g = g + (0.2*g) ;
System.out.println("new salary of G. Manager" + g);
}
}