package com.lti.Hibernate.Book_db;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory = 
    			Persistence.createEntityManagerFactory("persistence1");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
    	
    	System.out.println("Starting Transaction");
    	entityManager.getTransaction().begin();
    	
    	Date now = new Date();
    	
    	Author auth = new Author();
    	auth.setName("Ranvindra Singh");
    	auth.setEmail("ravindra@gmail.com");
    	entityManager.persist(auth);
    	
    	Book boo = new Book();
    	boo.setTitle("The master");
    	boo.setDescription("Book bye abc");
    	boo.setPublisheDate(now);
    	boo.setAuthor(auth);
    	System.out.println("Saving Book to Datebase\n");
    	entityManager.persist(boo);
    	
    	entityManager.getTransaction().commit();
    	
    }
}
