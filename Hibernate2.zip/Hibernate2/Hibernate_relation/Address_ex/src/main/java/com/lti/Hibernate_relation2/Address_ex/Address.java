package com.lti.Hibernate_relation2.Address_ex;

import javax.persistence.Column;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "address")
public class Address {
	@Id
	@Column(name="address_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator= "add_sequence")
	@SequenceGenerator(name="add_sequence" , sequenceName= "add_seq1")
	//@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="gen")
	@GenericGenerator(name="add_sequence",strategy="foreign",parameters=@Parameter(name="property",value="student"))
	
	private long id;
	
	@Column(name="street")
    private String street;
	
	@Column(name="city")
    private String city;
	
	@Column(name="country")
    private String country;
	
	@OneToOne
	@PrimaryKeyJoinColumn
	private Student student;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return "Address [id=" + id + ", street=" + street + ", city=" + city + ", country=" + country + ", student="
				+ student + "]";
	}
	
	
	
}
