package com.lti.assign1.assignment2;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vicky1");
        EntityManager entityManager=entityManagerFactory.createEntityManager();
        
        System.out.println("Starting Transaction");
        entityManager.getTransaction().begin();
        
        Bank banku = new Bank("sbi");
      
        Customer u1=new Customer("Vicky","bangalore",banku);
        Customer u2=new Customer("Vicky1","bangalore1",banku);
        Customer u3=new Customer("Vicky2","bangalore2",banku);
        
        
        Set<Customer> custo=new HashSet<Customer>();
        custo.add(u1);
        custo.add(u2);
        custo.add(u3);
     
        
        banku.setCustomers(custo);
        System.out.println("saving to db");
        entityManager.persist(banku);
      
        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
