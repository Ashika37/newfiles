package com.lti.assignment3.Assignnew;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Producers1")
public class Producers {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "my_entity_seq_gen_E")
	@SequenceGenerator(name="my_entity_seq_gen_E", sequenceName="Producers_seq",allocationSize=1)
	
    @Column(name="Producers_id")
    private int Producers_id;
    
    @Column(name="name")
    private String name;
    
    @Column(name="pname")
    private String pname;
    

    @OneToOne(mappedBy="producers")
    private Movies movies;

   
    public Producers() {
		super();
	}

	


	public Producers(String name, String pname, Movies movies) {
		super();
		this.name = name;
		this.pname = pname;
		this.movies = movies;
	}




	public int getProducers_id() {
		return Producers_id;
	}



	public void setProducers_id(int producers_id) {
		Producers_id = producers_id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public Movies getMovies() {
		return movies;
	}



	public void setMovies(Movies movies) {
		this.movies = movies;
	}



	public String getPname() {
		return pname;
	}




	public void setPname(String pname) {
		this.pname = pname;
	}




	@Override
	public String toString() {
		return "Producers [Producers_id=" + Producers_id + ", name=" + name + ", pname=" + pname + ", movies="
				+ movies + "]";
	}

	
}
