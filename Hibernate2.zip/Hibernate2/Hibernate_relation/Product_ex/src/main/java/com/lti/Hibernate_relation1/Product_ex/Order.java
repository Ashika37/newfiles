package com.lti.Hibernate_relation1.Product_ex;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "order7")
public class Order {
	
	private int o_id;
	private Date date;
	private Product product;
	
	public Order() {
		super();
	}

	@Id
	@Column(name = "o_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator= "ordernew_sequence")
	@SequenceGenerator(name="ordernew_sequence" , sequenceName= "ordernew_seq1")
	public int geto_id() {
		return o_id;
	}

	public void seto_id(int o_id) {
		this.o_id = o_id;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "orderDate")
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	
	@OneToOne( cascade = CascadeType.ALL)
	@JoinColumn( name = "product_id" )
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	
	
}
