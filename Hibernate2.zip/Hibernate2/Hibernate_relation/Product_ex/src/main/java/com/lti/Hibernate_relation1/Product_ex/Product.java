package com.lti.Hibernate_relation1.Product_ex;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "product7")
public class Product {
	
	private int id;
	private String product_name;
	private int product_price;
	
	public Product() {

	}

	public Product(String product_name, int product_price) {
		super();
		this.product_name = product_name;
		this.product_price = product_price;
	}

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator= "product_sequence")
	@SequenceGenerator(name="product_sequence" , sequenceName= "product_seq1")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}	

	@Column(name = "product_name")
	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	@Column(name = "product_price")
	public int getProduct_price() {
		return product_price;
	}

	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}	
	
	
	
}
