package com.lti.Hibernate_relation1.Product_ex;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App 
{
    public static void main( String[] args )
    {
   
    	EntityManagerFactory entityManagerFactory = 
    			Persistence.createEntityManagerFactory("persistence");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
    	
    	System.out.println("Starting Transaction");
    	entityManager.getTransaction().begin();
    	
    	Date now = new Date();
    	
    	Product pro = new Product();
    	pro.setProduct_name("Table1");
    	pro.setProduct_price(50);
    	
    	
    	Order order1 = new Order();
    	order1.setDate(now);
    	entityManager.persist(pro);
    	order1.setProduct(pro);
    	System.out.println("Saving Book to Datebase\n");
    	entityManager.persist(order1);
    	
    	entityManager.getTransaction().commit();
    }
}
