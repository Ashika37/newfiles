package com.lti.assignment1.assign;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class App 
{
    public static void main( String[] args )
    {
      
    	EntityManagerFactory entityManagerFactory = 
    			Persistence.createEntityManagerFactory("persistence1");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
    	
    	System.out.println("Starting Transaction");
    	entityManager.getTransaction().begin();
    	
    	Date now = new Date();
    	
    	Producer prod = new Producer();
    
    	Movies mov = new Movies();
    	mov.setMovie_name("ddlj");
    	
    	mov.setProducer(prod);
    	entityManager.persist(prod);
       	prod.setName("Yash raj");
    	System.out.println("Saving  to Datebase\n");
    	entityManager.persist(mov);
    	
    	entityManager.getTransaction().commit();
    	
    }
}
