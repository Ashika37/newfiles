package com.lti.assignment1.assign;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "movies")
public class Movies {
	
	private long mov_id;
	private String movie_name;
	

	private Producer producer;
	
	public Movies() {
		super();
	}

	@Id
	@Column(name = "mov_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator= "movie_sequence")
	@SequenceGenerator(name="movie_sequence" , sequenceName= "movie_seq1")
	public long getMov_id() {
		return mov_id;
	}

	public void setMov_id(long mov_id) {
		this.mov_id = mov_id;
	}

	
	public String getMovie_name() {
		return movie_name;
	}

	public void setMovie_name(String movie_name) {
		this.movie_name = movie_name;
	}

	
	@OneToOne( cascade = CascadeType.ALL)
	@JoinColumn( name = "prod_id" )
	public Producer getProducer() {
		return producer;
	}

	public void setProducer(Producer producer) {
		this.producer = producer;
	}
	
	

}
