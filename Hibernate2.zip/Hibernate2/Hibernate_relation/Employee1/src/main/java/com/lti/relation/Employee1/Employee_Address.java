package com.lti.relation.Employee1;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="employee_address221")
public class Employee_Address {

	@Id
	@Column(name="addr_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator= "add_sequence12")
	@SequenceGenerator(name="add_sequence12" , sequenceName= "add_seq12",allocationSize=1)
	private int addrId;
	
	@Column(name="street")
	private String street;
	@Column(name="city")
	private String city;
	@Column(name="state")
	private String state;
	@Column(name="country")
	private String country;
	
	@OneToOne(cascade= CascadeType.ALL)
    @JoinColumn(name = "emp_id")
    private Employeeold1 employee;

    public Employee_Address()
    {
        super();
    }

	public Employee_Address(int addrId, String street, String city, String state, String country,
			Employeeold1 employee) {
		super();
		this.addrId = addrId;
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.employee = employee;
	}
	public int getAddrId() {
		return addrId;
	}

	public void setAddrId(int addrId) {
		this.addrId = addrId;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Employeeold1 getEmployee() {
		return employee;
	}

	public void setEmployeeold1(Employeeold1 employee) {
		this.employee = employee;
	}
}
