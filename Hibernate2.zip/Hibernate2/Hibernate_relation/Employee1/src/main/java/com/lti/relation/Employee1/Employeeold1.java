package com.lti.relation.Employee1;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="employeeold22")
public class Employeeold1 {

	@Id
	@Column(name="emp_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator= "add_sequence11")
	@SequenceGenerator(name="add_sequence11" , sequenceName= "add_seq11")
	private int empid;
	
	
	@Column(name="name")
	private String empname;
	
	
	@OneToOne(mappedBy="employee")
	private Employee_Address employeeaddress;


	public Employeeold1() {
		super();
	}


	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public String getEmpname() {
		return empname;
	}


	public void setEmpname(String empname) {
		this.empname = empname;
	}


	public Employee_Address getEmployeeaddress() {
		return employeeaddress;
	}


	public void setEmployeeaddress(Employee_Address employeeaddress) {
		this.employeeaddress = employeeaddress;
	}
}
