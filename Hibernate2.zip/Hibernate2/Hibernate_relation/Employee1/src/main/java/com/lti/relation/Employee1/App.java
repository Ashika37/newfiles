package com.lti.relation.Employee1;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory = 
    			Persistence.createEntityManagerFactory("persistencenew");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
    	
    	System.out.println("Starting Transaction");
    	entityManager.getTransaction().begin();
    	
    	Employeeold1 empold = new Employeeold1();
    	
    	
    	Employee_Address empadd = new Employee_Address();
    	empadd.setStreet("new street");
    	empadd.setCity("bangalore");
    	empadd.setCountry("India");	
    	
    	empadd.setEmployeeold1(empold);
    	entityManager.persist(empold);
    	empold.setEmpname("Ila");
    	entityManager.persist(empadd);
    	
    	System.out.println("Saving hi to Datebase\n");
    
    	
    	entityManager.getTransaction().commit();
    	
    }
}
