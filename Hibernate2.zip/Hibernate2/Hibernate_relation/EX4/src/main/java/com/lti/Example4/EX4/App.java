package com.lti.Example4.EX4;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App 
{
    public static void main( String[] args )
    {
  
    	EntityManagerFactory entityManagerFactory = 
    			Persistence.createEntityManagerFactory("per1");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
    	
    	System.out.println("Starting Transaction");
    	entityManager.getTransaction().begin();
    	
    	
    	// Movv m=new Movv("Dilwale");
    	 //Movv m1=new Movv("DDLJ", s);
    	 
    	 
    	
    }
}
