package com.lti.Example4.EX4;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Prod1")
public class Prod {
	private static final String cascadeType = null;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="prod-seq")
	@SequenceGenerator(name="prod-seq",sequenceName="in_seq")
	@Column(name="id")
	private int id;
	
	@Column(name="pname")
	private String pname;
	
	//@OneToMany(mappedBy="producer", cascade= CascadeType.ALL)
	private Set<Movv> mov;

	public Prod() {
		super();
	}

	
	public Prod(String pname) {
		super();
		this.pname = pname;
	}


	public Prod(int id, String pname, Set<Movv> mov) {
		super();
		this.id = id;
		this.pname = pname;
		this.mov = mov;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Set<Movv> getMov() {
		return mov;
	}

	public void setMov(Set<Movv> mov) {
		this.mov = mov;
	}
	
	
	
}
