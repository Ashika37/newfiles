package com.lti.Example4.EX4;

import javax.enterprise.inject.spi.Producer;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Movies")
public class Movv {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="mov-seq")
	@SequenceGenerator(name="mov-seq",sequenceName="in_seq")
	@Column(name="id")
	private int id;
	@Column(name="movieName")
	private String movieName;
	@Column(name="producer")

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	
}
