package com.lti.newproject.new1;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class App 
{
    public static void main( String[] args )
    {
		EntityManagerFactory entityManagerFactory =  Persistence.createEntityManagerFactory("persistence19");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting Transaction");
		entityManager.getTransaction().begin();
		Employeen employee = new Employeen();
		
		employee.setName("Ramesh");
		employee.setBranch("Mysuru");
		System.out.println("Saving Employee to Database");

		entityManager.persist(employee);
		entityManager.getTransaction().commit();
		System.out.println("Generated Employee ID ="  + employee.getEmployeeId());
		Employeen emp=entityManager.find(Employeen.class, employee.getEmployeeId());
		System.out.println("got object " + emp.getName() + " "+emp.getEmployeeId());

		
		 Query query=entityManager.createQuery("from Employee");//classname

	     List<Employeen> list =query.getResultList();
	     Iterator<Employeen> itr =list.iterator();
	     while(itr.hasNext())
	    		 {
	    	 Employeen q=itr.next();
	    	 System.out.println("Employee name"+q.getName()+" Emp branch "+q.getBranch());
	    		 }
	     
	    }
    }

