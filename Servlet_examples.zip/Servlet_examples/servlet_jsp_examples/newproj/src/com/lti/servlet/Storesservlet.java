package com.lti.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.dao.StoresDAO;
import com.lti.model.Stores;

@WebServlet("/")
public class Storesservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private StoresDAO storesDAO;
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewStoreForm(request, response);
				break;
			case "/insert":
				insertStore(request, response);
				break;
			case "/delete":
				deleteStore(request, response);
				break;
			case "/edit":
				showEditStoreForm(request, response);
				break;
			case "/update":
				updateStore(request, response);
				break;
			default:
				listStore(request, response);
				
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}
	private void listStore(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Stores> listStore = storesDAO.selectAllStores();
		request.setAttribute("listStore", listStore);
		RequestDispatcher dispatcher = request.getRequestDispatcher("store-list.jsp");
		dispatcher.forward(request, response);
		
	}
	private void showNewStoreForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("store-form.jsp");
		dispatcher.forward(request, response);
		
	}
	private void showEditStoreForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int store_id = Integer.parseInt(request.getParameter("store_id"));
		Stores existinstore = storesDAO.selectStores(store_id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
		request.setAttribute("store", existinstore);
		dispatcher.forward(request, response);
	}
	private void insertStore(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		String address = request.getParameter("address");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String zipcode = request.getParameter("zipcode");
		Stores newStore = new Stores(address, city, state,zipcode);
		storesDAO.insertStore(newStore);
		response.sendRedirect("list");
	}
	private void updateStore(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int store_id = Integer.parseInt(request.getParameter("store_id"));
		String address = request.getParameter("address");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String zipcode = request.getParameter("zipcode");
		Stores stores = new Stores(store_id,address,city,state,zipcode);
		storesDAO.updateUser(stores);
		response.sendRedirect("list");
		
	}	
	private void deleteStore(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
	
		int store_id = Integer.parseInt(request.getParameter("store_id"));
		storesDAO.deleteUser(store_id);
		response.sendRedirect("list");
	}
}
