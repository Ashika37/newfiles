package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.model.Stores;

public class StoresDAO {
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "shandb1";
	private String jdbcPassword = "tiger";

	private static final String INSERT_STORES_SQL = "INSERT INTO stores VALUES "
			+ " (user_seq.NEXTVAL,?, ?, ?,?)";
	
	private static final String SELECT_STORES_BY_ID = "select store_id,address,city,"
			+ "state,zipcode from stores where id =?";
	private static final String SELECT_ALL_STORES = "select * from stores";
	private static final String DELETE_STORES_SQL = "delete from stores where store_id = ?";
	private static final String UPDATE_STORES_SQL = "update stores set address = ?,"
			+ "city= ?, state =? ,zipcode=? where store_id = ?";

	public StoresDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertStore(Stores store) throws SQLException {
		System.out.println(INSERT_STORES_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_STORES_SQL);
			preparedStatement.setString(1, store.getAddress());
			preparedStatement.setString(2, store.getCity());
			preparedStatement.setString(3, store.getState());
			preparedStatement.setString(4, store.getZipcode());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Stores selectStores(int store_id) {
		Stores store = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_STORES_BY_ID);
			preparedStatement.setInt(1, store_id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {			
				String address = rs.getString("address");
				String city = rs.getString("city");
				String state = rs.getString("state");
				String zipcode = rs.getString("zipcode");
				store = new Stores(store_id, address, city, state,zipcode);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return store;
	}

	public List<Stores> selectAllStores() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Stores> store = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_STORES);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int store_id = rs.getInt("store_id");
				String address = rs.getString("address");
				String city = rs.getString("city");
				String state = rs.getString("state");
				String zipcode = rs.getString("zipcode");
				store.add(new Stores(store_id, address, city, state,zipcode));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return store;
	}

	public boolean deleteUser(int store_id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_STORES_SQL);) {
			statement.setInt(1, store_id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(Stores store) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_STORES_SQL);) {
			
			statement.setString(1, store.getAddress());
			statement.setString(2, store.getCity());
			statement.setString(3, store.getState());
			statement.setString(4, store.getZipcode());
			statement.setInt(5, store.getStore_id());
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
				ex.printStackTrace();		
				}		
}
