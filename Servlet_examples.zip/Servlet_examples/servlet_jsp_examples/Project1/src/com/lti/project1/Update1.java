package com.lti.project1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Update1")
public class Update1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		ResultSet rs;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String location = request.getParameter("location");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
		
			String sql = "insert into dept00 values(?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setString(3,location);
			int rows = ps.executeUpdate();
			
			ps.close();
			if(name.equals("cs")){
				out.println("<h1><font color='red'><b>welcome to "+name+"</b></font></h1>");
				RequestDispatcher rd = request.getRequestDispatcher("Welcomeservlet");
				rd.forward(request, response);
			}
			else{
				out.println("<h1><font color='red'><b>Ypu have entered wrong data</b></font></h1>");
				RequestDispatcher rd = request.getRequestDispatcher("Welcomeservlet");
				rd.forward(request, response);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
