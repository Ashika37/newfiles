package com.lti.project1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Delete1")
public class Delete1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con= null;
		ResultSet rs;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		int author_id1  = Integer.parseInt(request.getParameter("id"));
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
			String sql = "delete from AUTHOR where AUTHOR_ID=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, author_id1);
			int rows = ps.executeUpdate();
			ps.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}


