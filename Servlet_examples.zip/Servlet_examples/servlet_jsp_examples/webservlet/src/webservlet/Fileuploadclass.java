package webservlet;

import javax.ws.rs.Path;

@Path("/files")
public class Fileuploadclass {

	@POST
	@Path("/upload")
	@Consumes(Media)
	
}
