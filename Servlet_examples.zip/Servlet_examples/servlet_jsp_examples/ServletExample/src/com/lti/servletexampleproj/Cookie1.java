package com.lti.servletexampleproj;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Cookie1
 */
public class Cookie1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Cookie1() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			
			String userName=request.getParameter("userName1").trim();
			String password=request.getParameter("password1").trim();
			
			out.print("Hello" +userName);
			out.print("Your passsword is " +password);
			
			Cookie c1 = new Cookie("userName1",userName);
			Cookie c2 = new Cookie("password1",password);
			
			response.addCookie(c1);                   //setting the cookie
			response.addCookie(c2);
			out.print("<br><a href='Cookie2' >View Details</a>");
			out.close();
			
		}catch(Exception e){
			System.out.println(e);
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
