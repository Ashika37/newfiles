package jsonex;

import java.io.File;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.eclipse.persistence.jaxb.UnmarshallerProperties;


public class jsonExample {
	     
	 public static void main(String[] args) 
	    {
	        Employee2 employee = new Employee2(1,"m","Gupta");
	         
	        jaxbObjectToJSON(employee);
	    }
	     
	    private static void jaxbObjectToJSON(Employee2 employee) 
	    {
	        try
	        {
	            JAXBContext jaxbContext = JAXBContext.newInstance(Employee2.class);
	            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
	 
	            // To format JSON
	            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE); 
	             
	            //Set JSON type
	            jaxbMarshaller.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json");
	            jaxbMarshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
	 
	            //Print JSON String to Console
	            StringWriter sw = new StringWriter();
	            jaxbMarshaller.marshal(employee, sw);
	            System.out.println(sw.toString());
	        } 
	        catch (JAXBException e) 
	        {
	            e.printStackTrace();
	        }
	    }
}
