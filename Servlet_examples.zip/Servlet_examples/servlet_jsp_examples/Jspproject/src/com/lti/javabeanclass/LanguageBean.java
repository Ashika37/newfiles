package com.lti.javabeanclass;

public class LanguageBean {

		private String name;
		private String language;
		public LanguageBean(){}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getLanguage() {
			return language;
		}
		public void setLanguage(String language) {
			this.language = language;
		}
		
		public String  getLanguageComments(){
			if(language.equals("java")){
				return "The king of OO Languages";
			}else if (language.equals("C++")){
				return "Rather too complex for some folks liking";
			}else if(language.equals("Perl")){
				return "Ok if you like incomprehensible code";
			}else{
				return " Sorry, Ive never heard of" +language+ ".";
			}
			
		}
		
}
