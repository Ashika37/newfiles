package com.lti.servletclass;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.javabeanclass.Employee;


@WebServlet("/EmpServlet")
public class EmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EmpServlet() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Employee> emplist = new ArrayList<Employee>();
		Employee emp1 = new Employee();
		emp1.setId(1);
		emp1.setName("Shan");
		emp1.setRole("Trainer");
		Employee emp2 = new Employee();
		emp2.setId(2);
		emp2.setName("Dinesh");
		emp2.setRole("Manager");
		emplist.add(emp1);
		emplist.add(emp2);
		request.setAttribute("empList", emplist);
		
		request.setAttribute("htmlTagData", "<br/> creates a new Line.");
		request.setAttribute("url", "https://www.google.co.in");
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/home.jsp");
			
	    
		rd.forward(request,response);
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
