
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/servletexample3")
public class servletexample3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String userName = null;
	
	public void service(HttpServletRequest req , HttpServletResponse resp) throws ServletException , IOException{
		resp.setContentType("text/plain");
		PrintWriter out = resp.getWriter();
		userName = req.getRemoteUser();
		sayHello(out);
		out.close();
	}
	private void sayHello(PrintWriter out) {
		// TODO Auto-generated method stub
		out.println("Hello there"  + userName);
		
	}


}
