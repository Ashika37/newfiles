package jaxB1;
import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class JAXBExample {
	
private static final String FILE_NAME ="jaxb-emp.xml";
public static void main(String[] args){
	Employee1 emp=new Employee1();
	emp.setId(1);;
	emp.setAge(25);;
	emp.setName("Shan");
	emp.setGender("Male");
	emp.setRole("Trainer");
	emp.setPassword("sensitive");
	
	jaxbObjectToXML(emp);

	
	Employee1 empFromFile = jaxbXMLToObject();
	System.out.println(empFromFile.toString());
}

private static Employee1 jaxbXMLToObject(){
	try{
		JAXBContext context = JAXBContext.newInstance(Employee1.class);
		Unmarshaller un =context.createUnmarshaller();
		Employee1 emp = (Employee1) un.unmarshal(new File(FILE_NAME));
		return emp;
	}
	catch (JAXBException e){
		e.printStackTrace();
	}
	return null;
	
}
private static void jaxbObjectToXML(Employee1 emp){
	try{
		JAXBContext context =JAXBContext.newInstance(Employee1.class);
		Marshaller m = context.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		m.marshal(emp,new File(FILE_NAME));
	}
	catch(JAXBException e){
		e.printStackTrace();
	}
}


}

