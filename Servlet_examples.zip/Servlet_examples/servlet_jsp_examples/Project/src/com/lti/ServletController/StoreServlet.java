package com.lti.ServletController;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.dao.BookDAO;
import com.lti.dao.StoreDAO;
import com.lti.model.Book;
import com.lti.model.Store;

/**
 * Servlet implementation class StoreServlet
 */
@WebServlet("/StoreServlet")
public class StoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private StoreDAO storeDAO;
	
    public StoreServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void init() {
    	storeDAO = new StoreDAO();
	}
    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String action = request.getServletPath();
		try{
			switch(action){
			case "/new":
				showStoreForm(request,response);
				break;
			case "/insert":
				insertStore(request,response);
				break;
			case "/delete":
				deleteStore(request,response);
				break;
			case "/edit":
				StoreEditForm(request,response);
				break;
			case "/update":
				updateStore(request,response);
				break;
			default:
				listStore(request,response);
						
			}
		}catch(Exception ex) {
			throw new ServletException(ex);
			
		}
	}


	private void listStore(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Store> storeUser = storeDAO.selectAllStore();
		request.setAttribute("storeUser",storeUser);
		RequestDispatcher dispatcher=request.getRequestDispatcher("store-list.jsp");
		dispatcher.forward(request, response);
		
	}

	private void updateStore(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		int STORE_ID = Integer.parseInt(request.getParameter("STORE_ID"));
		String ADDRESS = request.getParameter("ADDRESS");
		String CITY = request.getParameter("CITY");
		String STATE = request.getParameter("STATE");
		String ZIPCODE = request.getParameter("ZIPCODE");
		Store store = new Store(STORE_ID,ADDRESS,CITY,STATE,ZIPCODE);
		storeDAO.insertStore(store);
		response.sendRedirect("list");
		
	}

	private void StoreEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int STORE_ID = Integer.parseInt(request.getParameter("STORE_ID"));
		Store existingUser = storeDAO.selectStore(STORE_ID);
		RequestDispatcher dispatcher=request.getRequestDispatcher("store-form.jsp");
		request.setAttribute("store", existingUser);
		dispatcher.forward(request, response);
		
	}

	private void deleteStore(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int STORE_ID = Integer.parseInt(request.getParameter("STORE_ID"));
		storeDAO.deleteStore(STORE_ID);
		response.sendRedirect("list");
		
	}

	private void insertStore(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
	
		String ADDRESS = request.getParameter("ADDRESS");
		String CITY = request.getParameter("CITY");
		String STATE = request.getParameter("STATE");
		String ZIPCODE = request.getParameter("ZIPCODE");
		Store newstore = new Store(ADDRESS,CITY,STATE,ZIPCODE);
		storeDAO.insertStore(newstore);
		response.sendRedirect("list");
		
	}

	private void showStoreForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher=request.getRequestDispatcher("store-form.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
