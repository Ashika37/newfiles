package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.lti.model.Book;
import com.lti.model.Customer;

public class CustomerDAO {
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "tiger";
	private static final String INSERT_CUSTOMER_SQL = "INSERT INTO Customers VALUES" +"(user_seq.NEXTVAL,?,?,?)";
	private static final String SELECT_CUSTOMER_BY_ID = "select CUSTOMER_ID,FIRST_NAME, LAST_NAME,ADDRESS,CITY,STATE,ZIPCODE from Customers";
	private static final String SELECT_CUSTOMER_USERS = "select * from Customers";
	private static final String DELETE_CUSTOMER_SQL = "delete from Customers where CUSTOMER_ID= ?";
	private static final String UPDATE_CUSTOMER_SQL = "update Customers set FIRST_NAME = ?";
	public CustomerDAO(){} 

	protected Connection getConnection() {
		Connection connection=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection=DriverManager.getConnection(jdbcURL,jdbcUsername,jdbcPassword);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return connection;
	}

	public void insertCustomer(Customer customer) throws SQLException {
		System.out.println(INSERT_CUSTOMER_SQL);
		 
		try {Connection connection =getConnection();
		PreparedStatement preparedStatement=connection.prepareStatement(INSERT_CUSTOMER_SQL);
		preparedStatement.setString(1,customer.getFIRST_NAME());
		preparedStatement.setString(2,customer.getLAST_NAME());
		preparedStatement.setString(3,customer.getADDRESS());
		preparedStatement.setString(4,customer.getCITY());
		preparedStatement.setString(5,customer.getSTATE());
		preparedStatement.setString(6,customer.getZIPCODE());
		System.out.println(preparedStatement);
		preparedStatement.executeUpdate();	
		} catch(SQLException e) {
			printSQLException(e);
		}
	}

	public Customer selectBook(int CUSTOMER_ID){
		Customer customer = null;
		try{
			Connection connection = getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(SELECT_CUSTOMER_BY_ID );
			preparedStatement.setInt(1,CUSTOMER_ID);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()){
				String FIRST_NAME = rs.getString("FIRST_NAME");
				String LAST_NAME= rs.getString("LAST_NAME");
				String ADDRESS = rs.getString("ADDRESS");
				String CITY = rs.getString("CITY");
				String STATE= rs.getString("STATE");
				String ZIPCODE = rs.getString("ZIPCODE");
				
				customer = new Customer(CUSTOMER_ID,FIRST_NAME,LAST_NAME,ADDRESS,CITY,STATE,ZIPCODE);	
			}
		} catch(SQLException e) {
			printSQLException(e);
		}
		return customer;
		
			

		}
	public ArrayList<Customer> selectAllCustomer(){
		ArrayList<Customer> customer=new ArrayList<>();
		try{
			Connection connection=getConnection();
			
			PreparedStatement preparedStatement=connection.prepareStatement(SELECT_CUSTOMER_USERS);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()){
			int CUSTOMER_ID = rs.getInt("CUSTOMER_ID");
			String FIRST_NAME = rs.getString("FIRST_NAME");
			String LAST_NAME= rs.getString("LAST_NAME");
			String ADDRESS = rs.getString("ADDRESS");
			String CITY = rs.getString("CITY");
			String STATE= rs.getString("STATE");
			String ZIPCODE = rs.getString("ZIPCODE");
			
			customer.add(new Customer(CUSTOMER_ID,FIRST_NAME,LAST_NAME,ADDRESS,CITY,STATE,ZIPCODE));
		}

	} catch(SQLException e) {
		printSQLException(e);
	}
	return customer;

		

	}
	public boolean deleteBook(int CUSTOMER_ID) throws SQLException{
		boolean rowDeleted;
		try(Connection connection=getConnection();
				PreparedStatement statement=connection.prepareStatement(DELETE_CUSTOMER_SQL);) {
				statement.setInt(1,CUSTOMER_ID);
				rowDeleted=statement.executeUpdate() >0;	
	}
		return rowDeleted;

	}

	public boolean updateBook(Customer customer) throws SQLException {
		boolean rowUpdated;
		try(Connection connection=getConnection();
				PreparedStatement statement=connection.prepareStatement(UPDATE_CUSTOMER_SQL);) {
			
			statement.setString(1,customer.getFIRST_NAME());
			statement.setString(2,customer.getLAST_NAME());
			statement.setString(3,customer.getADDRESS());
			statement.setString(4,customer.getCITY());
			statement.setString(5,customer.getSTATE());
			statement.setString(6,customer.getZIPCODE());
			statement.setInt(7,customer.getCUSTOMER_ID());
			rowUpdated=statement.executeUpdate() >0;	
		}
		return rowUpdated;
			
		}
	private void printSQLException(SQLException ex){
		ex.printStackTrace();
	}
}
