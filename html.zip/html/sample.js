function sample() {
    alert('Hello in sample.js!!')
    
}