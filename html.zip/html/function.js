function average(a, b, c)
{
    var total;
    total=a+b+c;
    return total/3;
}