package Hibernate_new_proj.Book_db;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App 
{
    public static void main1( String[] args )
    {
    	EntityManagerFactory entityManagerFactory = 
    			Persistence.createEntityManagerFactory("new");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
    	
    	System.out.println("Starting Transaction");
    	entityManager.getTransaction().begin();
    	
    	Address add = new Address();
    	Student stu = new Student();
    	add.setStreet("street5");
    	add.setCity("Delhi");
    	add.setCountry("India");
    	add.setStudent(stu);
    	entityManager.persist(add);
    	
    	stu.setFirstname("Asha");
    	stu.setLastname("R");
    	stu.setSection("A");
    	stu.setAddress(add);

    	System.out.println("Saving hi to Datebase\n");
    	entityManager.persist(stu);
    	
    	entityManager.getTransaction().commit();
    }
}