package com.lti.Mapping_ex1.Order;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class App 
{
    public static void main( String[] args )
    {
    	int ch,n;
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Choose an Option\n");
    	System.out.println("1.Insert\n 2. Update\n3.Delete\n");
    	ch = sc.nextInt();
    	switch(ch){
    	
    	case 1:insert();
    		break;
    		
    	case 2:update();
    		break;
    		
    	case 3:delete();
    		break;
    	
    	}
    }

	private static void delete() {	
		EntityManagerFactory entityManagerFactory = 
    			Persistence.createEntityManagerFactory("persistence");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Delete");
    	entityManager.getTransaction().begin();
    	
    	Query query = entityManager.createQuery("DELETE FROM Ordernew e WHERE e.order_name = :order_name1 ");
        query.setParameter("order_name1", "Delivered1");
        int rowsDeleted = query.executeUpdate();
        System.out.println("entities deleted: " + rowsDeleted);
        entityManager.getTransaction().commit();
       
       @SuppressWarnings("unchecked")
       List<Ordernew> listEmployee = entityManager.
       createQuery("SELECT e From Ordernew e").getResultList();
   		
       if (listEmployee == null) {
   		System.out.println("No order found. ");
   		
   		} else {
   		for (Ordernew ord1 : listEmployee) {
   			System.out.println("Order Name = " + ord1.getOrder_name() + ","
   					+ "Order ID = " + ord1.getOrder_Id() + "Order Date " + ord1.getDate() );
   		}
   	} 	
   	entityManager.close();
   	entityManagerFactory.close();     
	}

	private static void update() {
		EntityManagerFactory entityManagerFactory = 
    			Persistence.createEntityManagerFactory("persistence");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Update");
    	entityManager.getTransaction().begin();
    	
    	Query query = entityManager.createQuery("UPDATE Ordernew e SET e.order_name = :order_name WHERE e.order_Id = :order_Id ");
        query.setParameter("order_name", "Delivered1");
       query.setParameter("order_Id", 1);
       int rowsUpdated = query.executeUpdate();
       System.out.println("entities Updated: " + rowsUpdated);
       entityManager.getTransaction().commit();
       
       @SuppressWarnings("unchecked")
       List<Ordernew> listEmployee = entityManager.
       createQuery("SELECT e From Ordernew e").getResultList();
   		
       if (listEmployee == null) {
   		System.out.println("No order found. ");  		
       } else {
   		for (Ordernew ord1 : listEmployee) {
   			System.out.println("Order Name = " + ord1.getOrder_name() + ","
   					+ "Order ID = " + ord1.getOrder_Id() + "Order Date " + ord1.getDate() );
   		}
   	}   	
   	entityManager.close();
   	entityManagerFactory.close();      
	}

	private static void insert() {
		EntityManagerFactory entityManagerFactory = 
    			Persistence.createEntityManagerFactory("persistence");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Insert");
    	entityManager.getTransaction().begin();
    	
    	Ordernew order = new Ordernew();
    	Date now = new Date();
    	
    	order.setDate(now);
    	order.setOrder_name("On the way");
    	
    	System.out.println("Saving Order to database");
    	entityManager.persist(order);
    	entityManager.getTransaction().commit();
    	System.out.println("Generated Order name = " + order.getOrder_name());
    	
    	Ordernew ord = entityManager.find(Ordernew.class, order.getOrder_Id());
    	System.out.println("got object " + ord.getOrder_name() + " " + ord.getOrder_Id());
    	
    	@SuppressWarnings("unchecked")
    	List<Ordernew> listEmployee = entityManager.
    	createQuery("SELECT e From Ordernew e").getResultList();
    	
    	if (listEmployee == null) {
    		System.out.println("No order found. ");
    		
    	} else {
    		for (Ordernew ord1 : listEmployee) {
    			System.out.println("Order Name = " + ord1.getOrder_name() + ","
    					+ "Order ID = " + ord1.getOrder_Id() + "Order Date " + ord1.getDate() );
    		}
    	}	
    	entityManager.close();
    	entityManagerFactory.close();	
	}
}
