package com.lti.Mapping_ex1.Order;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "orderdetails")
public class OrderDetails {
	
	private int order_details_Id;
	private int order_price;
	private Ordernew ordern;
	
	@Id
	/*@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO,generator= "order_sequence1")
	@SequenceGenerator(name="order_sequence1" , sequenceName= "order_detail_seq1")
	public int getOrder_details_Id() {
		return order_details_Id;
	}
	public void setOrder_details_Id(int order_details_Id) {
		this.order_details_Id = order_details_Id;
	}*/
	
	@Column(name = "orderprice")
	public int getOrder_price() {
		return order_price;
	}
	public void setOrder_price(int order_price) {
		this.order_price = order_price;
	}
}
