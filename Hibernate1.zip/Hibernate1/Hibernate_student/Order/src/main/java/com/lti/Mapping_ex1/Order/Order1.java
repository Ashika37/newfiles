package com.lti.Mapping_ex1.Order;

import java.util.Date;

public class Order1 {

	private Date date;
	private Product product;
	
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	
	
}
