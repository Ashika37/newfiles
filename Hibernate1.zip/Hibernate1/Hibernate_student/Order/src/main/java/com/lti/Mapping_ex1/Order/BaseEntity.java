package com.lti.Mapping_ex1.Order;

public class BaseEntity {

	
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}
