package com.lti.Mapping_ex1.Order;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "ordernew1")
public class Ordernew {

	private int order_Id;
	private String order_name;
	private Date date;
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO,generator= "order_sequence")
	@SequenceGenerator(name="order_sequence" , sequenceName= "order_seq1")
	public int getOrder_Id() {
		return order_Id;
	}
	public void setOrder_Id(int order_Id) {
		this.order_Id = order_Id;
	}
	
	@Column(name = "ordername")
	public String getOrder_name() {
		return order_name;
	}
	public void setOrder_name(String order_name) {
		this.order_name = order_name;
	}
	
	@Column(name = "orderdate")
	@Temporal(TemporalType.DATE)
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Ordernew [order_Id=" + order_Id + ", order_name=" + order_name + ", date=" + date + "]";
	}
}
