package com.lti.Mapping_ex.Employee1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "employeenew")
public class Employeenew {
	private int employeeId;
	
	private String name;
	private String branch;
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO,generator= "employeenew_sequence")
	@SequenceGenerator(name="employeenew_sequence" , sequenceName= "empnew_seq1")
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	@Column(name = "empname")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "branch")
	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	@Override
	public String toString() {
		return "Employeenew [employeeId=" + employeeId + ", name=" + name + ", branch=" + branch + "]";
	}
	
}
