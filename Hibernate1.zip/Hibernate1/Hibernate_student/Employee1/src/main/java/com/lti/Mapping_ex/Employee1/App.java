package com.lti.Mapping_ex.Employee1;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App 
{
    public static void main( String[] args )
    {
    
    	EntityManagerFactory entityManagerFactory = 
    			Persistence.createEntityManagerFactory("persistence");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
    	
    	System.out.println("Starting Transaction");
    	entityManager.getTransaction().begin();
    	Employeenew employee = new Employeenew();
    	employee.setName("Ila");
    	employee.setBranch("Delhi");
    	System.out.println("Saving EmployeeNew to database");
    	
    	entityManager.persist(employee);
    	entityManager.getTransaction().commit();
    	System.out.println("Generated Employee Id = " + employee.getEmployeeId());
    	
    	Employeenew emp = entityManager.find(Employeenew.class, employee.getEmployeeId());
    	System.out.println("got object " + emp.getName() + " " + emp.getEmployeeId());
    	
    	@SuppressWarnings("unchecked")
    	List<Employeenew> listEmployee = entityManager.
    	createQuery("SELECT e From Employeenew e").getResultList();
    	
    	if (listEmployee == null) {
    		System.out.println("No employee found. ");
    		
    	} else {
    		for (Employeenew emp1 : listEmployee) {
    			System.out.println("Employee name= " + emp1.getName() + ","
    					+ "Employee id = " + emp1.getEmployeeId() );
    		}
    	}
    	
    	entityManager.close();
    	entityManagerFactory.close();
    	
    }
}
